<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    protected $table = 'customers';

    protected $guarded = [];

    protected $casts = [
        'first_order' => 'datetime',
        'last_order'  => 'datetime',
    ];
}
