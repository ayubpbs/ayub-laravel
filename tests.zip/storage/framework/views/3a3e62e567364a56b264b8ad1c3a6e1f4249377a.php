<?php $__env->startSection('title', 'Customers'); ?>

<?php $__env->startSection('content'); ?>
  <div class="ad-bar">
    <h1 class="ad-title">Customers</h1>
    <a class="ad-btn" href="<?php echo e(route('admin.customers.create')); ?>">+ Add customer</a>
  </div>

  <div class="ad-stats">
    <div class="ad-stat"><span class="n"><?php echo e($summary['customers']); ?></span><span class="l">Total customers</span></div>
    <div class="ad-stat"><span class="n"><?php echo e($summary['repeat']); ?></span><span class="l">Repeat customers (2+ orders)</span></div>
    <div class="ad-stat"><span class="n"><?php echo e($summary['new_month']); ?></span><span class="l">New this month</span></div>
  </div>

  <form class="ad-filter" method="GET" action="<?php echo e(route('admin.customers.index')); ?>">
    <input type="text" name="q" value="<?php echo e($q); ?>" placeholder="Search by mobile, name or order number (#123)…">
    <select name="sort">
      <option value="recent" <?php echo e($sort === 'recent' ? 'selected' : ''); ?>>Latest order first</option>
      <option value="orders" <?php echo e($sort === 'orders' ? 'selected' : ''); ?>>Most orders</option>
      <option value="spent"  <?php echo e($sort === 'spent'  ? 'selected' : ''); ?>>Highest spending</option>
    </select>
    <button type="submit" class="ad-btn ad-btn-gray">Search</button>
    <?php if($q !== ''): ?><a class="ad-btn ad-btn-gray" href="<?php echo e(route('admin.customers.index')); ?>">Clear</a><?php endif; ?>
  </form>

  <?php if($canCreate): ?>
    <section class="ad-card">
      <p>No customer found with the number <strong><?php echo e($norm); ?></strong>.</p>
      <a class="ad-btn" href="<?php echo e(route('admin.customers.create', ['phone' => $norm])); ?>">Add this customer</a>
    </section>
  <?php endif; ?>

  <?php if($others->isNotEmpty()): ?>
    <section class="ad-card">
      <h2>Also found</h2>
      <div class="ad-scroll">
        <table class="ad-table">
          <tr><th>Customer</th><th>Mobile</th><th>Where</th><th>Orders</th><th></th></tr>
          <?php $__currentLoopData = $others; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><a href="<?php echo e(route('admin.customers.show', $o['phone'])); ?>"><strong><?php echo e($o['name'] ?: '—'); ?></strong></a></td>
              <td><?php echo e($o['phone']); ?></td>
              <td><?php echo e($o['label']); ?></td>
              <td><?php echo e($o['orders']); ?></td>
              <td><a class="ad-link" href="<?php echo e(route('admin.customers.show', $o['phone'])); ?>">View</a></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
      </div>
    </section>
  <?php endif; ?>

  <?php if(!$canCreate): ?>
  <section class="ad-card">
    <?php if($customers->isEmpty()): ?>
      <p class="ad-muted"><?php echo e($q !== '' ? 'No customers with orders match your search.' : 'No customers yet. They appear here once an order is placed.'); ?></p>
    <?php else: ?>
      <div class="ad-scroll">
        <table class="ad-table">
          <tr><th>Customer</th><th>Mobile</th><th>Orders</th><th>Delivered total</th><th>Cancelled / Returned</th><th>Last order</th><th></th></tr>
          <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $l = $latest->get($c->last_order_id); ?>
            <tr>
              <td>
                <a href="<?php echo e(route('admin.customers.show', $c->phone)); ?>"><strong><?php echo e($l->name ?? '—'); ?></strong></a>
                <?php if($c->orders_count > 1): ?><span class="ad-st st-confirmed">Repeat</span><?php endif; ?>
              </td>
              <td><a href="tel:<?php echo e($c->phone); ?>"><?php echo e($c->phone); ?></a></td>
              <td><?php echo e($c->orders_count); ?></td>
              <td>৳ <?php echo e(number_format($c->delivered_total)); ?></td>
              <td class="<?php echo e($c->failed_count > 0 ? 'ad-red' : ''); ?>"><?php echo e($c->failed_count); ?></td>
              <td><?php echo e(\Illuminate\Support\Carbon::parse($c->last_order_at)->format('d M Y')); ?></td>
              <td><a class="ad-link" href="<?php echo e(route('admin.customers.show', $c->phone)); ?>">View</a></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
      </div>
      <div class="ad-pager"><?php echo e($customers->links('pagination::simple-default')); ?></div>
    <?php endif; ?>
  </section>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/customers/index.blade.php ENDPATH**/ ?>