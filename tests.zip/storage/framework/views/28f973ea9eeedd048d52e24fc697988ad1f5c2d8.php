
<?php
    $navMenu   = $adminNavMenu ?? [];
    $navAcc    = $adminNavAccounting ?? [];
    $pageTitle = trim(strip_tags($__env->yieldContent('title')));

    // Where a menu item leads: its own url, or the first url among its children
    $landing = function (array $item) {
        if (!empty($item['url'])) {
            return $item['url'];
        }
        foreach (($item['children'] ?? []) as $c) {
            if (!empty($c['url'])) {
                return $c['url'];
            }
        }

        return null;
    };

    // Which module is the current route in? (first sidebar item that is "on")
    $module = null;
    $isAcc  = false;
    foreach ($navMenu as $it) {
        if (!empty($it['view'])) {
            if ($it['view'] === 'admin.partials.accounting-menu' && $navAcc && request()->routeIs('admin.accounting.*')) {
                $module = $it;
                $isAcc  = true;
                break;
            }
            continue;
        }
        if (!empty($it['on'])) {
            $module = $it;
            break;
        }
    }

    $row1 = [];
    $row2 = [];
    $crumbs = [];
    $leaf = false; // true once the breadcrumb ends on a real menu item

    if ($module) {
        $crumbs[] = ['label' => 'Admin', 'url' => route('admin.dashboard')];

        if ($isAcc) {
            $crumbs[] = ['label' => $module['label'], 'url' => $landing(['children' => $navAcc])];

            $section = null;
            foreach ($navAcc as $s) {
                $url = $landing($s);
                if (!$url) {
                    continue;
                }
                $row1[] = ['label' => $s['label'], 'url' => $url, 'on' => !empty($s['on'])];
                if (!empty($s['on'])) {
                    $section = $s;
                }
            }

            if ($section) {
                if (!empty($section['children'])) {
                    $crumbs[] = ['label' => $section['label'], 'url' => $landing($section)];
                    foreach ($section['children'] as $c) {
                        if (empty($c['url'])) {
                            continue;
                        }
                        $row2[] = ['label' => $c['label'], 'url' => $c['url'], 'on' => !empty($c['on'])];
                        if (!empty($c['on'])) {
                            $crumbs[] = ['label' => $c['label']];
                            $leaf = true;
                        }
                    }
                } else {
                    $crumbs[] = ['label' => $section['label']];
                    $leaf = true;
                }
            }
        } elseif (!empty($module['children'])) {
            $crumbs[] = ['label' => $module['label'], 'url' => $landing($module)];
            foreach ($module['children'] as $c) {
                if (empty($c['url'])) {
                    continue; // "coming soon" items are not links
                }
                $row1[] = [
                    'label' => $c['label'], 'url' => $c['url'], 'on' => !empty($c['on']),
                    'count' => $c['count'] ?? null, 'hot' => !empty($c['hot']),
                ];
                if (!empty($c['on'])) {
                    $crumbs[] = ['label' => $c['label']];
                    $leaf = true;
                }
            }
        } else {
            $crumbs[] = ['label' => $module['label'], 'url' => $module['url'] ?? null];
            $leaf = true;
        }

        // A page that is not a menu item (an order, a product being edited ...): end on the page title
        $lastLabel = $crumbs ? end($crumbs)['label'] : '';
        if (!$leaf && $pageTitle !== '' && strcasecmp($pageTitle, $lastLabel) !== 0) {
            $crumbs[] = ['label' => $pageTitle];
        } elseif ($leaf === true && !$row1 && count($crumbs) === 2 && $pageTitle !== '' && strcasecmp($pageTitle, $lastLabel) !== 0
                && request()->url() !== strtok((string) ($module['url'] ?? ''), '?')) {
            // single-page module (Customers, Coupons ...) on a deeper page such as one customer, not on its own list page
            $crumbs[] = ['label' => $pageTitle];
        }
    }

    $showCrumbs = count($crumbs) >= 3;
?>

<?php if($row1 || $showCrumbs): ?>
  <nav class="ad-subnav" aria-label="Section navigation">
    <div class="ad-subnav-in">
      <?php if($showCrumbs): ?>
        <ol class="ad-crumbs">
          <?php $__currentLoopData = $crumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($loop->last || empty($c['url'])): ?>
              <li aria-current="page"><?php echo e($c['label']); ?></li>
            <?php else: ?>
              <li><a href="<?php echo e($c['url']); ?>"><?php echo e($c['label']); ?></a></li>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
      <?php endif; ?>

      <?php if($row1): ?>
        <div class="ad-subnav-row">
          <?php $__currentLoopData = $row1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="ad-subnav-link <?php echo e($l['on'] ? 'on' : ''); ?>" href="<?php echo e($l['url']); ?>" <?php if($l['on']): ?> aria-current="page" <?php endif; ?>>
              <span><?php echo e($l['label']); ?></span>
              <?php if(isset($l['count'])): ?><span class="ad-subnav-count <?php echo e(!empty($l['hot']) && $l['count'] > 0 ? 'hot' : ''); ?>"><?php echo e($l['count']); ?></span><?php endif; ?>
            </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      <?php endif; ?>

      <?php if($row2): ?>
        <div class="ad-subnav-row ad-subnav-row2">
          <?php $__currentLoopData = $row2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="ad-subnav-link <?php echo e($l['on'] ? 'on' : ''); ?>" href="<?php echo e($l['url']); ?>" <?php if($l['on']): ?> aria-current="page" <?php endif; ?>><span><?php echo e($l['label']); ?></span></a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      <?php endif; ?>
    </div>
  </nav>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/partials/subnav.blade.php ENDPATH**/ ?>