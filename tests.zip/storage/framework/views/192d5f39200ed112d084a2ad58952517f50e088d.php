<?php $__env->startSection('title', 'Old Customers'); ?>

<?php $__env->startSection('content'); ?>
  <div class="ad-bar">
    <h1 class="ad-title">Old Customers</h1>
  </div>

  <div class="ad-stats">
    <div class="ad-stat"><span class="n"><?php echo e($summary['customers']); ?></span><span class="l">Total customers</span></div>
    <div class="ad-stat"><span class="n"><?php echo e($summary['repeat']); ?></span><span class="l">Repeat customers (2+ orders)</span></div>
  </div>

  <form class="ad-filter" method="GET" action="<?php echo e(route('admin.imported-customers.index')); ?>">
    <input type="text" name="q" value="<?php echo e($q); ?>" placeholder="Search by name, mobile or address…">
    <select name="sort">
      <option value="recent" <?php echo e($sort === 'recent' ? 'selected' : ''); ?>>Latest order first</option>
      <option value="orders" <?php echo e($sort === 'orders' ? 'selected' : ''); ?>>Most orders</option>
    </select>
    <button type="submit" class="ad-btn ad-btn-gray">Search</button>
    <?php if($q !== ''): ?><a class="ad-btn ad-btn-gray" href="<?php echo e(route('admin.imported-customers.index')); ?>">Clear</a><?php endif; ?>
  </form>

  <section class="ad-card">
    <?php if($customers->isEmpty()): ?>
      <p class="ad-muted"><?php echo e($q !== '' ? 'No customers match your search.' : 'No customers found.'); ?></p>
    <?php else: ?>
      <div class="ad-scroll">
        <table class="ad-table">
          <tr><th>Customer</th><th>Mobile</th><th>Address</th><th>Orders</th><th>First order</th><th>Last order</th></tr>
          <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>
                <strong><?php echo e($c->name ?: '—'); ?></strong>
                <?php if($c->total_orders > 1): ?><span class="ad-st st-confirmed">Repeat</span><?php endif; ?>
              </td>
              <td><a href="tel:<?php echo e($c->phone); ?>"><?php echo e($c->phone); ?></a></td>
              <td><?php echo e(trim(implode(', ', array_filter([$c->address, $c->area, $c->zone, $c->city])))); ?></td>
              <td><?php echo e($c->total_orders); ?></td>
              <td><?php echo e($c->first_order ? $c->first_order->format('d M Y') : '—'); ?></td>
              <td><?php echo e($c->last_order ? $c->last_order->format('d M Y') : '—'); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
      </div>
      <div class="ad-pager"><?php echo e($customers->links('pagination::simple-default')); ?></div>
    <?php endif; ?>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/customers/imported.blade.php ENDPATH**/ ?>