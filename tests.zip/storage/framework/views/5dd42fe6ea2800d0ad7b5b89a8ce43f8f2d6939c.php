<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('content'); ?>
  <?php $heading = $status === '' ? 'All Orders' : \App\Models\Order::statuses()[$status] . ' Orders'; ?>
  <div class="ad-bar">
    <h1 class="ad-title"><?php echo e($heading); ?></h1>
    <form method="GET" action="<?php echo e(route('admin.orders.index')); ?>" class="ad-filter" style="margin:0">
      <?php if($status !== ''): ?><input type="hidden" name="status" value="<?php echo e($status); ?>"><?php endif; ?>
      <input type="text" name="q" value="<?php echo e($search); ?>" placeholder="Search name, mobile or order no.">
      <button type="submit" class="ad-btn">Search</button>
      <?php if($search !== ''): ?><a class="ad-btn ad-btn-gray" href="<?php echo e(route('admin.orders.index', $status !== '' ? ['status' => $status] : [])); ?>">Clear</a><?php endif; ?>
    </form>
  </div>

  <div class="ad-tabs">
    <a href="<?php echo e(route('admin.orders.index')); ?>" class="<?php echo e($status === '' ? 'on' : ''); ?>">All (<?php echo e($counts->sum()); ?>)</a>
    <?php $__currentLoopData = \App\Models\Order::statuses(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="<?php echo e(route('admin.orders.index', ['status' => $key])); ?>" class="<?php echo e($status === $key ? 'on' : ''); ?>"><?php echo e($label); ?> (<?php echo e($counts[$key] ?? 0); ?>)</a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

  <section class="ad-card">
    <?php if($orders->isEmpty()): ?>
      <p class="ad-muted"><?php echo e($search !== '' ? 'No orders match your search.' : 'No orders.'); ?></p>
    <?php else: ?>
      <div class="ad-scroll">
        <table class="ad-table">
          <tr><th>No.</th><th>Date</th><th>Customer</th><th>Mobile</th><th>Total</th><th>Payment</th><th>Status</th><th></th></tr>
          <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><a href="<?php echo e(route('admin.orders.show', $o->id)); ?>"><strong>#<?php echo e($o->id); ?></strong></a></td>
              <td><?php echo e($o->created_at->format('d M Y, h:i A')); ?></td>
              <td><?php echo e($o->name); ?></td>
              <td><a href="tel:<?php echo e($o->phone); ?>"><?php echo e($o->phone); ?></a></td>
              <td>৳ <?php echo e(number_format($o->total)); ?></td>
              <td><span class="ad-st <?php echo e(\App\Models\Order::paymentBadge($o->paymentStatus())); ?>"><?php echo e($o->paymentLabel()); ?></span></td>
              <td><span class="ad-st st-<?php echo e($o->status); ?>"><?php echo e($o->statusLabel()); ?></span></td>
              <td><a class="ad-link" href="<?php echo e(route('admin.orders.show', $o->id)); ?>">View</a></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
      </div>
      <div class="ad-pager"><?php echo e($orders->links('pagination::simple-default')); ?></div>
    <?php endif; ?>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>