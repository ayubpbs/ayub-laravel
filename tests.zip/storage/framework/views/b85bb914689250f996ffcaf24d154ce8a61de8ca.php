<?php $__env->startSection('title', $name); ?>

<?php $__env->startSection('content'); ?>
  <p class="ad-crumbs"><a href="<?php echo e(route('admin.customers.index')); ?>">← All customers</a></p>
  <h1 class="ad-title"><?php echo e($name); ?></h1>

  <div class="ad-stats">
    <div class="ad-stat"><span class="n"><?php echo e($stats['orders']); ?></span><span class="l">Total orders</span></div>
    <div class="ad-stat"><span class="n"><?php echo e($stats['delivered']); ?></span><span class="l">Delivered</span></div>
    <div class="ad-stat <?php echo e($stats['failed'] > 0 ? 'ad-stat-hot' : ''); ?>"><span class="n"><?php echo e($stats['failed']); ?></span><span class="l">Cancelled / Returned</span></div>
    <div class="ad-stat"><span class="n">৳ <?php echo e(number_format($stats['spent'])); ?></span><span class="l">Delivered total</span></div>
  </div>

  <div class="ad-two">
    <section class="ad-card">
      <h2>Details</h2>
      <dl class="ad-dl">
        <dt>Mobile</dt><dd><a href="tel:<?php echo e($phone); ?>"><?php echo e($phone); ?></a></dd>
        <?php if($latest): ?>
          <dt>Latest address</dt><dd><?php echo e($latest->address); ?></dd>
          <dt>First order</dt><dd><?php echo e($stats['first']->format('d M Y')); ?></dd>
          <dt>Last order</dt><dd><?php echo e($latest->created_at->format('d M Y, h:i A')); ?></dd>
        <?php else: ?>
          <dt>Orders</dt><dd>No orders yet</dd>
        <?php endif; ?>
        <?php if($names->count() > 1): ?>
          <dt>Names used</dt><dd><?php echo e($names->implode(', ')); ?></dd>
        <?php endif; ?>
        <?php if($profile && $profile->notes): ?>
          <dt>Internal note</dt><dd><?php echo e($profile->notes); ?></dd>
        <?php endif; ?>
        <?php if($profile): ?>
          <dt>Profile added</dt><dd><?php echo e($profile->created_at->format('d M Y')); ?><?php echo e($profile->created_by_name ? ' by ' . $profile->created_by_name : ''); ?></dd>
        <?php endif; ?>
        <?php if($imported): ?>
          <dt>Old site</dt><dd><?php echo e($imported->total_orders); ?> order(s) before this system<?php echo e($imported->last_order ? ', last on ' . $imported->last_order->format('d M Y') : ''); ?></dd>
        <?php endif; ?>
      </dl>
    </section>

    <section class="ad-card">
      <h2>Addresses used</h2>
      <?php $oldAddress = $imported ? trim(implode(', ', array_filter([$imported->address, $imported->area, $imported->zone, $imported->city]))) : ''; ?>
      <?php if($addresses->isEmpty() && $oldAddress === ''): ?>
        <p class="ad-muted">No address yet.</p>
      <?php else: ?>
        <ul style="margin:0;padding-left:18px">
          <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($a); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php if($oldAddress !== '' && !$addresses->contains($oldAddress)): ?><li><?php echo e($oldAddress); ?> <span class="ad-muted">(old site)</span></li><?php endif; ?>
        </ul>
      <?php endif; ?>
    </section>
  </div>

  <section class="ad-card">
    <h2>Order history</h2>
    <?php if($orders->isEmpty()): ?>
      <p class="ad-muted">No orders yet.</p>
    <?php else: ?>
    <div class="ad-scroll">
      <table class="ad-table">
        <tr><th>No.</th><th>Date</th><th>Items</th><th>Total</th><th>Payment</th><th>Status</th><th>Courier</th><th></th></tr>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><a href="<?php echo e(route('admin.orders.show', $o->id)); ?>"><strong>#<?php echo e($o->id); ?></strong></a></td>
            <td><?php echo e($o->created_at->format('d M Y, h:i A')); ?></td>
            <td>
              <?php $__currentLoopData = $o->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div><?php echo e($i->title); ?> × <?php echo e($i->quantity); ?></div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td>৳ <?php echo e(number_format($o->total)); ?></td>
            <td><span class="ad-st <?php echo e(\App\Models\Order::paymentBadge($o->paymentStatus())); ?>"><?php echo e($o->paymentLabel()); ?></span></td>
            <td><span class="ad-st st-<?php echo e($o->status); ?>"><?php echo e($o->statusLabel()); ?></span></td>
            <td>
              <?php if($o->consignment_id): ?>
                <?php echo e(\App\Support\Steadfast::label($o->courier_status)); ?>

                <?php if($o->tracking_code): ?><div class="ad-muted"><?php echo e($o->tracking_code); ?></div><?php endif; ?>
              <?php else: ?>
                —
              <?php endif; ?>
            </td>
            <td><a class="ad-link" href="<?php echo e(route('admin.orders.show', $o->id)); ?>">View</a></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
    </div>
    <?php endif; ?>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/customers/show.blade.php ENDPATH**/ ?>