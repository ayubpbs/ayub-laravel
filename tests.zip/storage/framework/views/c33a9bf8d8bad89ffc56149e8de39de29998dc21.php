<?php $__env->startSection('title', 'Add Customer'); ?>

<?php $__env->startSection('content'); ?>
  <p class="ad-crumbs"><a href="<?php echo e(route('admin.customers.index')); ?>">← All customers</a></p>
  <h1 class="ad-title">Add Customer</h1>

  <form class="ad-card ad-form" method="POST" action="<?php echo e(route('admin.customers.store')); ?>">
    <?php echo csrf_field(); ?>

    <label>Mobile number *
      <input type="text" name="phone" value="<?php echo e(old('phone', $phone)); ?>" required maxlength="30" placeholder="01712345678" inputmode="tel">
      <small>Any format works (+880…, 880…, Bangla digits). It is saved as 01XXXXXXXXX. If this number is already a customer, you are taken to that customer.</small>
    </label>

    <label>Name *
      <input type="text" name="name" value="<?php echo e(old('name')); ?>" required maxlength="100">
    </label>

    <label>Internal note <small>(optional, only staff can see it)</small>
      <textarea name="notes" rows="3" maxlength="500"><?php echo e(old('notes')); ?></textarea>
    </label>

    <div class="ad-submit">
      <button type="submit" class="ad-btn">Add Customer</button>
      <a class="ad-btn ad-btn-gray" href="<?php echo e(route('admin.customers.index')); ?>">Cancel</a>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/customers/create.blade.php ENDPATH**/ ?>