<?php

use App\Http\Controllers\Admin\CustomerController;
use App\Http\Middleware\AdminAuth;
use Illuminate\Support\Facades\Route;

// Admin: add a customer by hand. Route names start with "admin.customers." so the existing
// "Customers" permission applies (see App\Support\AdminAccess).
Route::prefix('admin')->name('admin.')->middleware(AdminAuth::class)->group(function () {
    Route::get('customers/create', [CustomerController::class, 'create'])->name('customers.create');
    Route::post('customers', [CustomerController::class, 'store'])->name('customers.store');
});
