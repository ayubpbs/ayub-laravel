<?php $__env->startSection('title', 'Invoices'); ?>

<?php $__env->startSection('content'); ?>
  <div class="ad-bar">
    <h1 class="ad-title">Invoices</h1>
    <?php if($stats['missing'] > 0): ?>
      <form action="<?php echo e(route('admin.invoices.generate.missing')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit" class="ad-btn">Create <?php echo e($stats['missing']); ?> missing invoice(s)</button>
      </form>
    <?php endif; ?>
  </div>

  <div class="ad-stats">
    <div class="ad-stat"><span class="n"><?php echo e($stats['total']); ?></span><span class="l">Total invoices</span></div>
    <div class="ad-stat"><span class="n"><?php echo e($stats['month']); ?></span><span class="l">Issued this month</span></div>
    <a class="ad-stat <?php echo e($stats['unpaid'] ? 'ad-stat-hot' : ''); ?>" href="<?php echo e(route('admin.invoices.index', ['pay' => 'unpaid'])); ?>"><span class="n"><?php echo e($stats['unpaid']); ?></span><span class="l">Unpaid invoices</span></a>
  </div>

  <form class="ad-filter" method="GET" action="<?php echo e(route('admin.invoices.index')); ?>">
    <input type="text" name="q" value="<?php echo e($q); ?>" placeholder="Invoice no., order no., name or mobile…">
    <select name="pay">
      <option value="">Any payment status</option>
      <option value="paid"    <?php echo e($pay === 'paid'    ? 'selected' : ''); ?>>Paid</option>
      <option value="partial" <?php echo e($pay === 'partial' ? 'selected' : ''); ?>>Partly paid</option>
      <option value="unpaid"  <?php echo e($pay === 'unpaid'  ? 'selected' : ''); ?>>Unpaid</option>
    </select>
    <input type="date" name="from" value="<?php echo e($from); ?>" title="From" style="flex:none;min-width:150px;width:160px">
    <input type="date" name="to" value="<?php echo e($to); ?>" title="To" style="flex:none;min-width:150px;width:160px">
    <button type="submit" class="ad-btn ad-btn-gray">Filter</button>
    <?php if($q !== '' || $pay !== '' || $from !== '' || $to !== ''): ?><a class="ad-btn ad-btn-gray" href="<?php echo e(route('admin.invoices.index')); ?>">Clear</a><?php endif; ?>
  </form>

  <section class="ad-card">
    <?php if($invoices->isEmpty()): ?>
      <p class="ad-muted">No invoices found. They are created automatically when an order is confirmed.</p>
    <?php else: ?>
      <form method="GET" action="<?php echo e(route('admin.invoices.print')); ?>" id="bulkPrint" target="_blank">
        <input type="hidden" name="ids" id="bulkIds">
        <div class="ad-scroll">
          <table class="ad-table">
            <tr><th><input type="checkbox" id="checkAll" aria-label="Select all"></th><th>Invoice</th><th>Order</th><th>Date</th><th>Customer</th><th class="r">Total</th><th class="r">Due</th><th>Payment</th><th></th></tr>
            <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $o = $inv->order; ?>
              <tr>
                <td><input type="checkbox" class="rowCheck" value="<?php echo e($inv->id); ?>"></td>
                <td><a href="<?php echo e(route('admin.invoices.show', $inv->id)); ?>"><strong><?php echo e($inv->number()); ?></strong></a></td>
                <td><a href="<?php echo e(route('admin.orders.show', $o->id)); ?>">#<?php echo e($o->id); ?></a></td>
                <td><?php echo e($inv->issued_at->format('d M Y')); ?></td>
                <td><?php echo e($o->name); ?><br><small class="ad-muted"><?php echo e($o->phone); ?></small></td>
                <td class="r">৳ <?php echo e(number_format($o->total)); ?></td>
                <td class="r <?php echo e($o->dueAmount() > 0 ? 'ad-red' : ''); ?>">৳ <?php echo e(number_format($o->dueAmount())); ?></td>
                <td><span class="ad-st <?php echo e(\App\Models\Order::paymentBadge($o->paymentStatus())); ?>"><?php echo e($o->paymentLabel()); ?></span><?php if($o->isLocked()): ?><br><span class="ad-st st-<?php echo e($o->status); ?>"><?php echo e($o->statusLabel()); ?></span><?php endif; ?></td>
                <td class="ad-actions"><a class="ad-link" href="<?php echo e(route('admin.invoices.show', $inv->id)); ?>" target="_blank">Print</a></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
        </div>
        <div class="ad-submit" style="margin-top:12px">
          <button type="submit" class="ad-btn ad-btn-gray">🖨 Print ticked invoices (max 50)</button>
        </div>
      </form>
      <div class="ad-pager"><?php echo e($invoices->links('pagination::simple-default')); ?></div>
      <script>
        document.getElementById('checkAll').addEventListener('change', function () {
          document.querySelectorAll('.rowCheck').forEach(function (c) { c.checked = this.checked; }, this);
        });
        document.getElementById('bulkPrint').addEventListener('submit', function (e) {
          var ids = Array.prototype.map.call(document.querySelectorAll('.rowCheck:checked'), function (c) { return c.value; });
          if (!ids.length) { e.preventDefault(); alert('Please tick at least one invoice.'); return; }
          document.getElementById('bulkIds').value = ids.join(',');
        });
      </script>
    <?php endif; ?>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/invoices/index.blade.php ENDPATH**/ ?>