<?php $__env->startSection('title', 'Products'); ?>

<?php $__env->startSection('content'); ?>
  <div class="ad-bar">
    <h1 class="ad-title">All Products <small class="ad-muted" style="font-size:15px;font-weight:400">(<?php echo e($products->total()); ?>)</small></h1>
    <a class="ad-btn" href="<?php echo e(route('admin.products.create')); ?>">＋ New Product</a>
  </div>

  <form class="ad-filter" method="GET" action="<?php echo e(route('admin.products.index')); ?>">
    <input type="text" name="q" value="<?php echo e($q); ?>" placeholder="Search by name, brand or SKU…">
    <select name="category">
      <option value="">All categories</option>
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($c->id); ?>" <?php echo e((string) $cat === (string) $c->id ? 'selected' : ''); ?>><?php echo e($c->depth ? '— ' : ''); ?><?php echo e($c->label); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <select name="brand">
      <option value="">All brands</option>
      <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($b->id); ?>" <?php echo e((string) $brand === (string) $b->id ? 'selected' : ''); ?>><?php echo e($b->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <select name="stock">
      <option value="">Any stock</option>
      <option value="in"  <?php echo e($stock === 'in'  ? 'selected' : ''); ?>>In stock</option>
      <option value="low" <?php echo e($stock === 'low' ? 'selected' : ''); ?>>Low stock (1–5)</option>
      <option value="out" <?php echo e($stock === 'out' ? 'selected' : ''); ?>>Out of stock</option>
    </select>
    <button type="submit" class="ad-btn ad-btn-gray">Search</button>
    <?php if($q !== '' || $cat !== '' || $brand !== '' || $stock !== ''): ?>
      <a class="ad-btn ad-btn-gray" href="<?php echo e(route('admin.products.index')); ?>">Clear</a>
    <?php endif; ?>
  </form>

  <section class="ad-card">
    <?php if($products->isEmpty()): ?>
      <p class="ad-muted">No products found.</p>
    <?php else: ?>
      <div class="ad-scroll">
        <table class="ad-table">
          <tr><th>Image</th><th>Name</th><th>Category</th><th>Brand</th><th>Price</th><th>Stock</th><th>Status</th><th></th></tr>
          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td class="ad-thumb">
                <?php if($p->image): ?>
                  <img src="<?php echo e(asset('uploads/products/' . $p->image)); ?>" alt="">
                <?php else: ?>
                  <span><?php echo e($p->icon ?: '📦'); ?></span>
                <?php endif; ?>
              </td>
              <td><a href="<?php echo e(route('admin.products.edit', $p->id)); ?>"><strong><?php echo e($p->title); ?></strong></a><?php if($p->sku): ?><br><small class="ad-muted">SKU: <?php echo e($p->sku); ?></small><?php endif; ?></td>
              <td><?php echo e(optional($p->category)->label ?: '—'); ?></td>
              <td><?php echo e($p->brand ?: '—'); ?></td>
              <td>৳ <?php echo e(number_format($p->price)); ?></td>
              <td class="<?php echo e($p->stock_quantity < 1 ? 'ad-red' : ''); ?>"><?php echo e($p->stock_quantity); ?></td>
              <td>
                <?php if(!$p->is_published): ?> <span class="ad-st st-cancelled">Draft</span>
                <?php elseif($p->is_upcoming): ?> <span class="ad-st st-shipped">Coming soon</span>
                <?php else: ?> <span class="ad-st st-delivered">Active</span>
                <?php endif; ?>
              </td>
              <td class="ad-actions">
                <a class="ad-link" href="<?php echo e(route('admin.products.edit', $p->id)); ?>">Edit</a>
                <form action="<?php echo e(route('admin.products.destroy', $p->id)); ?>" method="POST" onsubmit="return confirm('Really delete this product?');">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="ad-link ad-del">Delete</button>
                </form>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
      </div>
      <div class="ad-pager"><?php echo e($products->links('pagination::simple-default')); ?></div>
    <?php endif; ?>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/products/index.blade.php ENDPATH**/ ?>