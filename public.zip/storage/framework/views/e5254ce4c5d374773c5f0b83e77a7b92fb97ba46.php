<?php $__env->startSection('title', 'Order Complete — ' . config('shop.name')); ?>

<?php $__env->startSection('content'); ?>
  <section class="section">
    <div class="success-box">
      <div class="success-icon">✔</div>
      <h1>Thank you, <?php echo e($order->name); ?>!</h1>
      <p>Your order has been received. Order number: <strong>#<?php echo e($order->id); ?></strong></p>
      <p>We will call <strong><?php echo e($order->phone); ?></strong> shortly to confirm your order.</p>

      <div class="summary success-summary">
        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="sum-row">
            <span><?php echo e($item->title); ?> × <?php echo e($item->quantity); ?></span>
            <span>৳ <?php echo e(number_format($item->line_total)); ?></span>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <hr>
        <div class="sum-row"><span>Delivery charge</span><span>৳ <?php echo e(number_format($order->delivery_charge)); ?></span></div>
        <div class="sum-row sum-total"><span>Total (cash on delivery)</span><span>৳ <?php echo e(number_format($order->total)); ?></span></div>
        <p class="addr">📍 <?php echo e($order->address); ?></p>
      </div>

      <a class="btn-primary" href="<?php echo e(route('home')); ?>">Continue shopping</a>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/checkout/success.blade.php ENDPATH**/ ?>