<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
  <?php if(!empty($backUrl)): ?>
    <p class="ad-crumbs"><a href="<?php echo e($backUrl); ?>">← <?php echo e($backLabel); ?></a></p>
  <?php endif; ?>
  <h1 class="ad-title"><?php echo e($heading); ?></h1>
  <?php if(!empty($subtitle)): ?>
    <p class="ad-muted" style="margin:-8px 0 14px"><?php echo e($subtitle); ?></p>
  <?php endif; ?>

  <?php echo $__env->make('admin.accounting.accounts._tabs', ['active' => $active], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="ad-stats">
    <div class="ad-stat"><span class="n <?php echo e($totals['balance'] < 0 ? 'ad-red' : ''); ?>">৳ <?php echo e(number_format($totals['balance'], 2)); ?></span><span class="l">Current balance</span></div>
    <div class="ad-stat"><span class="n">৳ <?php echo e(number_format((float) $account->opening_balance, 2)); ?></span><span class="l">Opening balance</span></div>
    <div class="ad-stat"><span class="n ad-green">৳ <?php echo e(number_format($totals['in'], 2)); ?></span><span class="l">Total money in</span></div>
    <div class="ad-stat"><span class="n ad-red">৳ <?php echo e(number_format($totals['out'], 2)); ?></span><span class="l">Total money out</span></div>
  </div>

  <div class="ad-two">
    <section class="ad-card">
      <h2>Add entry</h2>
      <form class="ad-form" action="<?php echo e($urlBase); ?>/entries" method="POST">
        <?php echo csrf_field(); ?>
        <div class="ad-row">
          <label>Type
            <select name="direction" required>
              <option value="in"  <?php echo e(old('direction', 'in') === 'in' ? 'selected' : ''); ?>>Money In (received)</option>
              <option value="out" <?php echo e(old('direction') === 'out' ? 'selected' : ''); ?>>Money Out (paid)</option>
            </select>
          </label>
          <label>Amount (৳)
            <input type="number" name="amount" value="<?php echo e(old('amount')); ?>" step="0.01" min="0.01" required>
          </label>
        </div>
        <div class="ad-row">
          <label>Date
            <input type="date" name="txn_date" id="txnDate" value="<?php echo e(old('txn_date', now()->toDateString())); ?>" required>
          </label>
          <label>Note <small>(optional)</small>
            <input type="text" name="note" value="<?php echo e(old('note')); ?>" maxlength="255" placeholder="e.g. Shop rent, customer payment…">
          </label>
        </div>
        <div class="ad-submit"><button type="submit" class="ad-btn">Save entry</button></div>
      </form>
    </section>

    <section class="ad-card">
      <h2>Opening balance</h2>
      <form class="ad-form" action="<?php echo e($urlBase); ?>/opening" method="POST">
        <?php echo csrf_field(); ?>
        <label>Balance before the first entry (৳)
          <input type="number" name="opening_balance" value="<?php echo e(old('opening_balance', (float) $account->opening_balance)); ?>" step="0.01" min="0" required>
        </label>
        <div class="ad-submit"><button type="submit" class="ad-btn ad-btn-gray">Save opening balance</button></div>
      </form>
      <p class="ad-hint">Set this once, to the money this account already held when you started using this page.</p>
    </section>
  </div>

  <section class="ad-card">
    <div class="ad-card-head"><h2>Transactions</h2></div>

    <form class="ad-filter" method="GET" action="<?php echo e($urlBase); ?>">
      <label>From <input type="date" name="from" value="<?php echo e($f['from']); ?>"></label>
      <label>To <input type="date" name="to" value="<?php echo e($f['to']); ?>"></label>
      <select name="dir">
        <option value="">Money in &amp; out</option>
        <option value="in"  <?php echo e($f['dir'] === 'in'  ? 'selected' : ''); ?>>Money in only</option>
        <option value="out" <?php echo e($f['dir'] === 'out' ? 'selected' : ''); ?>>Money out only</option>
      </select>
      <button type="submit" class="ad-btn ad-btn-gray">Filter</button>
      <?php if($filtered): ?>
        <a class="ad-btn ad-btn-gray" href="<?php echo e($urlBase); ?>">Reset</a>
      <?php endif; ?>
    </form>

    <?php if($transactions->isEmpty()): ?>
      <p class="ad-muted">No entries found.</p>
    <?php else: ?>
      <div class="ad-scroll">
        <table class="ad-table">
          <tr><th>Date</th><th>Note</th><th class="r">Money in</th><th class="r">Money out</th><th></th></tr>
          <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($tx->txn_date->format('d M Y')); ?></td>
              <td><?php echo e($tx->note ?: '—'); ?><?php if($tx->source !== 'manual'): ?> <span class="ad-muted">(<?php echo e(ucfirst($tx->source)); ?>)</span><?php endif; ?></td>
              <td class="r"><?php if($tx->isIn()): ?><span class="ad-green">৳ <?php echo e(number_format((float) $tx->amount, 2)); ?></span><?php else: ?> — <?php endif; ?></td>
              <td class="r"><?php if(!$tx->isIn()): ?><span class="ad-red">৳ <?php echo e(number_format((float) $tx->amount, 2)); ?></span><?php else: ?> — <?php endif; ?></td>
              <td class="ad-actions">
                <?php if($tx->source === 'manual'): ?>
                  <form action="<?php echo e($urlBase); ?>/entries/<?php echo e($tx->id); ?>" method="POST" onsubmit="return confirm('Delete this entry?')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="ad-link ad-del">Delete</button>
                  </form>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php if($filtered): ?>
            <tr class="ad-tfoot">
              <td colspan="2">Total of this filtered list</td>
              <td class="r">৳ <?php echo e(number_format($period['in'], 2)); ?></td>
              <td class="r">৳ <?php echo e(number_format($period['out'], 2)); ?></td>
              <td></td>
            </tr>
          <?php endif; ?>
        </table>
      </div>
      <div class="ad-pager"><?php echo e($transactions->links('pagination::simple-default')); ?></div>
    <?php endif; ?>
  </section>

  <script>
    // Default the date to the browser's local day (the server clock may be in another time zone)
    (function () {
      var d = document.getElementById('txnDate');
      if (d && !<?php echo e(old('txn_date') ? 'true' : 'false'); ?>) {
        d.value = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
      }
    })();
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/accounting/accounts/show.blade.php ENDPATH**/ ?>