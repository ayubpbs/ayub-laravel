<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
  <h1 class="ad-title">Dashboard</h1>

  <div class="ad-stats">
    <a class="ad-stat ad-stat-hot" href="<?php echo e(route('admin.orders.index', ['status' => 'pending'])); ?>">
      <span class="n"><?php echo e($stats['pending']); ?></span><span class="l">New orders (to review)</span>
    </a>
    <div class="ad-stat"><span class="n"><?php echo e($stats['today']); ?></span><span class="l">Today's orders</span></div>
    <div class="ad-stat"><span class="n"><?php echo e($stats['orders']); ?></span><span class="l">Total orders</span></div>
    <div class="ad-stat"><span class="n">৳ <?php echo e(number_format($stats['delivered'])); ?></span><span class="l">Delivered sales</span></div>
    <a class="ad-stat" href="<?php echo e(route('admin.products.index')); ?>"><span class="n"><?php echo e($stats['products']); ?></span><span class="l">Total products</span></a>
  </div>

  <div class="ad-two">
    <section class="ad-card">
      <div class="ad-card-head"><h2>Recent orders</h2><a href="<?php echo e(route('admin.orders.index')); ?>">View all →</a></div>
      <?php if($recent->isEmpty()): ?>
        <p class="ad-muted">No orders yet.</p>
      <?php else: ?>
        <div class="ad-scroll">
          <table class="ad-table">
            <tr><th>No.</th><th>Name</th><th>Total</th><th>Status</th></tr>
            <?php $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><a href="<?php echo e(route('admin.orders.show', $o->id)); ?>">#<?php echo e($o->id); ?></a></td>
                <td><?php echo e($o->name); ?></td>
                <td>৳ <?php echo e(number_format($o->total)); ?></td>
                <td><span class="ad-st st-<?php echo e($o->status); ?>"><?php echo e($o->statusLabel()); ?></span></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
        </div>
      <?php endif; ?>
    </section>

    <section class="ad-card">
      <div class="ad-card-head"><h2>Low / out of stock</h2></div>
      <?php if($lowStock->isEmpty()): ?>
        <p class="ad-muted">All products have enough stock.</p>
      <?php else: ?>
        <div class="ad-scroll">
          <table class="ad-table">
            <tr><th>Product</th><th>Stock</th></tr>
            <?php $__currentLoopData = $lowStock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><a href="<?php echo e(route('admin.products.edit', $p->id)); ?>"><?php echo e($p->title); ?></a></td>
                <td class="<?php echo e($p->stock_quantity < 1 ? 'ad-red' : ''); ?>"><?php echo e($p->stock_quantity); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
        </div>
      <?php endif; ?>
    </section>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>