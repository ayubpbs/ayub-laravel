<?php $__env->startSection('title', 'Bank Accounts'); ?>

<?php $__env->startSection('content'); ?>
  <h1 class="ad-title">🏦 Bank Accounts</h1>

  <?php echo $__env->make('admin.accounting.accounts._tabs', ['active' => 'bank'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="ad-stats">
    <div class="ad-stat"><span class="n <?php echo e($total < 0 ? 'ad-red' : ''); ?>">৳ <?php echo e(number_format($total, 2)); ?></span><span class="l">Total in all banks</span></div>
    <div class="ad-stat"><span class="n"><?php echo e($rows->count()); ?></span><span class="l">Bank accounts</span></div>
  </div>

  <section class="ad-card">
    <div class="ad-card-head"><h2>Your bank accounts</h2></div>
    <?php if($rows->isEmpty()): ?>
      <p class="ad-muted">No bank account yet. Add your first one below.</p>
    <?php else: ?>
      <div class="ad-scroll">
        <table class="ad-table">
          <tr><th>Bank</th><th>Account no.</th><th class="r">Balance</th><th></th></tr>
          <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><a href="<?php echo e(route('admin.accounting.banks.show', $r['account']->id)); ?>"><strong><?php echo e($r['account']->name); ?></strong></a></td>
              <td><?php echo e($r['account']->account_no ?: '—'); ?></td>
              <td class="r"><span class="<?php echo e($r['balance'] < 0 ? 'ad-red' : ''); ?>">৳ <?php echo e(number_format($r['balance'], 2)); ?></span></td>
              <td class="ad-actions">
                <a class="ad-link" href="<?php echo e(route('admin.accounting.banks.show', $r['account']->id)); ?>">Open</a>
                <a class="ad-link" href="<?php echo e(route('admin.accounting.banks.index', ['edit' => $r['account']->id])); ?>#bankForm">Edit</a>
                <form action="<?php echo e(route('admin.accounting.banks.destroy', $r['account']->id)); ?>" method="POST" onsubmit="return confirm('Delete this bank account?')">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="ad-link ad-del">Delete</button>
                </form>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
      </div>
      <p class="ad-hint">A bank account with entries cannot be deleted. Delete its entries first.</p>
    <?php endif; ?>
  </section>

  <section class="ad-card" id="bankForm">
    <?php if($editing): ?>
      <h2>Edit bank account</h2>
      <form class="ad-form" action="<?php echo e(route('admin.accounting.banks.update', $editing->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="ad-row">
          <label>Bank name
            <input type="text" name="name" value="<?php echo e(old('name', $editing->name)); ?>" maxlength="60" required>
          </label>
          <label>Account number <small>(optional)</small>
            <input type="text" name="account_no" value="<?php echo e(old('account_no', $editing->account_no)); ?>" maxlength="40">
          </label>
        </div>
        <div class="ad-submit">
          <button type="submit" class="ad-btn">Save changes</button>
          <a class="ad-btn ad-btn-gray" href="<?php echo e(route('admin.accounting.banks.index')); ?>">Cancel</a>
        </div>
      </form>
      <p class="ad-hint">The opening balance is changed on the account's own page.</p>
    <?php else: ?>
      <h2>Add bank account</h2>
      <form class="ad-form" action="<?php echo e(route('admin.accounting.banks.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="ad-row">
          <label>Bank name
            <input type="text" name="name" value="<?php echo e(old('name')); ?>" maxlength="60" placeholder="e.g. Dutch-Bangla Bank, City Bank" required>
          </label>
          <label>Account number <small>(optional)</small>
            <input type="text" name="account_no" value="<?php echo e(old('account_no')); ?>" maxlength="40">
          </label>
          <label>Opening balance (৳)
            <input type="number" name="opening_balance" value="<?php echo e(old('opening_balance', 0)); ?>" step="0.01" min="0">
          </label>
        </div>
        <div class="ad-submit"><button type="submit" class="ad-btn">Add bank account</button></div>
      </form>
    <?php endif; ?>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/accounting/accounts/banks.blade.php ENDPATH**/ ?>