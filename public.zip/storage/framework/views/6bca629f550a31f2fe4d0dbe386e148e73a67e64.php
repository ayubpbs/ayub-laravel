<?php $__env->startSection('title', 'Reviews'); ?>

<?php $__env->startSection('content'); ?>
  <div class="ad-bar">
    <h1 class="ad-title">Customer Reviews</h1>
  </div>

  <?php if(!$available): ?>
    <section class="ad-card">
      <p class="ad-muted">Reviews are not set up yet. Run <code>php artisan migrate</code> once to create the reviews table.</p>
    </section>
  <?php else: ?>
    <?php
      $tabs = ['pending' => 'Pending', 'approved' => 'Approved', 'rejected' => 'Rejected', 'all' => 'All'];
    ?>
    <div style="display:flex;flex-wrap:wrap;gap:8px;margin:0 0 14px">
      <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $n = $key === 'all' ? $counts->sum() : ($counts[$key] ?? 0); ?>
        <a class="ad-btn <?php echo e($status === $key ? '' : 'ad-btn-gray'); ?>" href="<?php echo e(route('admin.reviews.index', ['status' => $key])); ?>"><?php echo e($label); ?> (<?php echo e($n); ?>)</a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <section class="ad-card">
      <?php if($reviews->isEmpty()): ?>
        <p class="ad-muted">No reviews here.</p>
      <?php else: ?>
        <div class="ad-scroll">
          <table class="ad-table">
            <tr><th>Product</th><th>Customer</th><th>Rating</th><th>Review</th><th>Date</th><th>Status</th><th></th></tr>
            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <?php if($r->product): ?>
                    <a href="<?php echo e(route('admin.products.edit', $r->product->id)); ?>"><strong><?php echo e($r->product->title); ?></strong></a>
                  <?php else: ?>
                    <span class="ad-muted">(deleted product)</span>
                  <?php endif; ?>
                </td>
                <td><?php echo e($r->name); ?></td>
                <td style="white-space:nowrap;color:#f5a623"><?php echo e($r->stars()); ?></td>
                <td style="max-width:360px;white-space:normal"><?php echo $r->comment ? nl2br(e($r->comment)) : '<span class="ad-muted">— no comment —</span>'; ?></td>
                <td style="white-space:nowrap"><?php echo e($r->created_at->format('d M Y')); ?></td>
                <td>
                  <?php if($r->status === 'approved'): ?> <span class="ad-st st-delivered">Approved</span>
                  <?php elseif($r->status === 'rejected'): ?> <span class="ad-st st-cancelled">Rejected</span>
                  <?php else: ?> <span class="ad-st st-shipped">Pending</span>
                  <?php endif; ?>
                </td>
                <td class="ad-actions">
                  <?php if($r->status !== 'approved'): ?>
                    <form action="<?php echo e(route('admin.reviews.approve', $r->id)); ?>" method="POST">
                      <?php echo csrf_field(); ?>
                      <button type="submit" class="ad-link">Approve</button>
                    </form>
                  <?php endif; ?>
                  <?php if($r->status !== 'rejected'): ?>
                    <form action="<?php echo e(route('admin.reviews.reject', $r->id)); ?>" method="POST">
                      <?php echo csrf_field(); ?>
                      <button type="submit" class="ad-link">Reject</button>
                    </form>
                  <?php endif; ?>
                  <form action="<?php echo e(route('admin.reviews.destroy', $r->id)); ?>" method="POST" onsubmit="return confirm('Really delete this review?');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="ad-link ad-del">Delete</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
        </div>
        <div class="ad-pager"><?php echo e($reviews->links('pagination::simple-default')); ?></div>
      <?php endif; ?>
    </section>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/reviews/index.blade.php ENDPATH**/ ?>