<?php
  $shopName = config('shop.name');
  $url      = $product->url();
  $gallery  = $product->galleryUrls();          // main image first, then the extra images
  $videos   = $product->videos();
  $img      = $gallery[0] ?? ($videos[0]['hq'] ?? null);   // used for social-media previews
  $state    = $product->stockState();
  $buyable  = in_array($state, ['in', 'low'], true);
  $metaDesc = $product->summary(160) ?: ($product->title . ' — ৳ ' . number_format($product->price) . ' at ' . $shopName);

  // Structured data for search engines (only facts that exist in the database)
  $ld = [
      '@context'    => 'https://schema.org',
      '@type'       => 'Product',
      'name'        => $product->title,
      'description' => $metaDesc,
      'url'         => $url,
      'offers'      => [
          '@type'         => 'Offer',
          'url'           => $url,
          'priceCurrency' => 'BDT',
          'price'         => (string) (int) $product->price,
          'availability'  => $state === 'upcoming' ? 'https://schema.org/PreOrder'
                           : ($buyable ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock'),
      ],
  ];
  if ($product->sku)   { $ld['sku'] = $product->sku; }
  if ($gallery)        { $ld['image'] = $gallery; }
  elseif ($img)        { $ld['image'] = [$img]; }
  if ($product->brand) { $ld['brand'] = ['@type' => 'Brand', 'name' => $product->brand]; }
  if ($specs = $product->specs()) {
      $ld['additionalProperty'] = array_map(function ($r) {
          return ['@type' => 'PropertyValue', 'name' => $r['name'], 'value' => $r['value']];
      }, $specs);
  }
  if ((int) $product->reviews > 0 && (float) $product->rating > 0) {
      $ld['aggregateRating'] = [
          '@type'       => 'AggregateRating',
          'ratingValue' => (string) $product->rating,
          'reviewCount' => (int) $product->reviews,
      ];
  }
?>

<?php $__env->startSection('title', $product->title . ' — ' . $shopName); ?>

<?php $__env->startPush('head'); ?>
  <meta name="description" content="<?php echo e($metaDesc); ?>">
  <link rel="canonical" href="<?php echo e($url); ?>">
  <meta property="og:type" content="product">
  <meta property="og:site_name" content="<?php echo e($shopName); ?>">
  <meta property="og:title" content="<?php echo e($product->title); ?>">
  <meta property="og:description" content="<?php echo e($metaDesc); ?>">
  <meta property="og:url" content="<?php echo e($url); ?>">
  <?php if($img): ?><meta property="og:image" content="<?php echo e($img); ?>"><?php endif; ?>
  <meta property="product:price:amount" content="<?php echo e((int) $product->price); ?>">
  <meta property="product:price:currency" content="BDT">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/product.css')); ?>">
  <script type="application/ld+json"><?php echo json_encode($ld, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP); ?></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
  <script src="<?php echo e(asset('assets/js/product.js')); ?>" defer></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
  <section class="section pd-page">
    <nav class="crumbs" aria-label="Breadcrumb">
      <a href="<?php echo e(route('home')); ?>">Home</a>
      <?php $__currentLoopData = $crumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        › <a href="<?php echo e(route('category.show', $c->id)); ?>"><?php echo e($c->label); ?></a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      › <span aria-current="page"><?php echo e($product->title); ?></span>
    </nav>

    <div class="pd">
      <?php echo $__env->make('shop.product._gallery', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->make('shop.product._buybox', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <?php echo $__env->make('shop.product._tabs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </section>

  <?php if($related->isNotEmpty()): ?>
    <section class="section">
      <div class="section-head"><h2>You may also like</h2></div>
      <div class="grid">
        <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo $__env->make('shop._card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </section>
  <?php endif; ?>

  <?php if($buyable): ?>
    
    <div class="pd-bar" data-pd-bar>
      <div class="pd-bar-price">৳ <?php echo e(number_format($product->price)); ?></div>
      <button type="submit" form="pd-buy-form" class="btn-outline pd-btn">🛒 Add to Cart</button>
      <button type="submit" form="pd-buy-form" name="buy_now" value="1" class="btn-primary pd-btn">Buy Now</button>
    </div>
  <?php endif; ?>

  <div class="pd-lightbox" data-pd-lightbox hidden role="dialog" aria-modal="true" aria-label="Product images">
    <button type="button" class="pd-lightbox-close" data-pd-close aria-label="Close">×</button>
    <?php if(count($gallery) > 1): ?>
      <button type="button" class="pd-lb-nav pd-lb-prev" data-pd-lb-prev aria-label="Previous image">‹</button>
      <button type="button" class="pd-lb-nav pd-lb-next" data-pd-lb-next aria-label="Next image">›</button>
    <?php endif; ?>
    <img src="" alt="<?php echo e($product->title); ?>">
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/shop/product.blade.php ENDPATH**/ ?>