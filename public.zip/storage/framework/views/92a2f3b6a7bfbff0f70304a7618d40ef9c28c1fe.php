<?php $__env->startSection('title', 'Cash Flow'); ?>

<?php $__env->startSection('content'); ?>
  <?php $m = fn ($v) => ($v < 0 ? '−' : '') . '৳ ' . number_format(abs($v), 2); ?>

  <h1 class="ad-title">🌊 Cash Flow</h1>

  <?php echo $__env->make('admin.accounting.reports._period', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="ad-stats">
    <div class="ad-stat"><span class="n"><?php echo e($m($open)); ?></span><span class="l">Balance at start</span></div>
    <div class="ad-stat"><span class="n ad-green"><?php echo e($m($in)); ?></span><span class="l">Money in</span></div>
    <div class="ad-stat"><span class="n ad-red"><?php echo e($m($out)); ?></span><span class="l">Money out</span></div>
    <div class="ad-stat ad-stat-hot"><span class="n <?php echo e($close < 0 ? 'ad-red' : ''); ?>"><?php echo e($m($close)); ?></span><span class="l">Balance at end</span></div>
  </div>

  <section class="ad-card">
    <h2>Every account</h2>
    <div class="ad-scroll">
      <table class="ad-table">
        <tr><th>Account</th><th class="r">Start</th><th class="r">In</th><th class="r">Out</th><th class="r">Transfer in</th><th class="r">Transfer out</th><th class="r">End</th></tr>
        <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($r['account']->type === 'bank' ? '🏦' : (\App\Models\Account::types()[$r['account']->type][1] ?? '')); ?> <?php echo e($r['account']->name); ?></td>
            <td class="r"><?php echo e($m($r['open'])); ?></td>
            <td class="r"><?php echo e($m($r['in'])); ?></td>
            <td class="r"><?php echo e($m($r['out'])); ?></td>
            <td class="r"><?php echo e($m($r['tIn'])); ?></td>
            <td class="r"><?php echo e($m($r['tOut'])); ?></td>
            <td class="r"><strong><?php echo e($m($r['close'])); ?></strong></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr><th>Total</th><th class="r"><?php echo e($m($open)); ?></th><th class="r"><?php echo e($m($in)); ?></th><th class="r"><?php echo e($m($out)); ?></th><th class="r" colspan="2">cancel out</th><th class="r"><?php echo e($m($close)); ?></th></tr>
      </table>
    </div>
    <p class="ad-hint">Transfers only move money between your own accounts, so they are not part of "Money in / out" and add up to zero in the total.</p>
  </section>

  <section class="ad-card">
    <h2>Month by month</h2>
    <?php if(empty($months)): ?>
      <p class="ad-muted">No money moved in this period.</p>
    <?php else: ?>
      <div class="ad-scroll">
        <table class="ad-table">
          <tr><th>Month</th><th class="r">Money in</th><th class="r">Money out</th><th class="r">Net</th></tr>
          <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $net = $mo['in'] - $mo['out']; ?>
            <tr>
              <td><?php echo e($mo['label']); ?></td>
              <td class="r"><?php echo e($m($mo['in'])); ?></td>
              <td class="r"><?php echo e($m($mo['out'])); ?></td>
              <td class="r <?php echo e($net < 0 ? 'ad-red' : 'ad-green'); ?>"><strong><?php echo e($m($net)); ?></strong></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
      </div>
    <?php endif; ?>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/accounting/reports/cash_flow.blade.php ENDPATH**/ ?>