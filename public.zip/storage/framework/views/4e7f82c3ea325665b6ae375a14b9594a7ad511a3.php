<?php $editing = $brand->exists; ?>

<?php $__env->startSection('title', $editing ? 'Edit Brand' : 'New Brand'); ?>

<?php $__env->startSection('content'); ?>
  <p class="ad-crumbs"><a href="<?php echo e(route('admin.brands.index')); ?>">← All brands</a></p>
  <h1 class="ad-title"><?php echo e($editing ? 'Edit Brand' : 'New Brand'); ?></h1>

  <form class="ad-card ad-form" method="POST" enctype="multipart/form-data"
        action="<?php echo e($editing ? route('admin.brands.update', $brand->id) : route('admin.brands.store')); ?>">
    <?php echo csrf_field(); ?>
    <?php if($editing): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

    <label>Brand name *
      <input type="text" name="name" value="<?php echo e(old('name', $brand->name)); ?>" required maxlength="100">
    </label>

    <div class="ad-row">
      <label>Sort order <small>(smaller numbers come first)</small>
        <input type="number" name="sort_order" value="<?php echo e(old('sort_order', $brand->sort_order ?? 0)); ?>" min="0">
      </label>
      <label>Logo <small>(optional, max 2 MB)</small>
        <input type="file" name="logo" accept="image/png,image/jpeg,image/webp">
      </label>
    </div>

    <?php if($editing && $brand->logo): ?>
      <div class="ad-current">
        <img src="<?php echo e(asset('uploads/brands/' . $brand->logo)); ?>" alt="">
        <label class="ad-check"><input type="checkbox" name="remove_logo" value="1"> Remove the current logo</label>
      </div>
    <?php endif; ?>

    <div class="ad-submit">
      <button type="submit" class="ad-btn"><?php echo e($editing ? 'Update' : 'Add Brand'); ?></button>
      <a class="ad-btn ad-btn-gray" href="<?php echo e(route('admin.brands.index')); ?>">Cancel</a>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/brands/form.blade.php ENDPATH**/ ?>