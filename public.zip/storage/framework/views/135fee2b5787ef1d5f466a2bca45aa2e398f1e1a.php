<?php
    $on = fn ($p) => request()->routeIs($p);
    $acct = fn ($t) => $on('admin.accounting.accounts.show') && request()->route('type') === $t;

    $acc = [
        ['label' => 'Dashboard', 'url' => route('admin.accounting.dashboard'), 'on' => $on('admin.accounting.dashboard')],
        ['label' => 'Income', 'on' => $on('admin.accounting.income.*'), 'children' => [
            ['label' => 'All Income', 'url' => route('admin.accounting.income.index'),  'on' => $on('admin.accounting.income.index')],
            ['label' => 'Add Income', 'url' => route('admin.accounting.income.create'), 'on' => $on('admin.accounting.income.create')],
        ]],
        ['label' => 'Expense', 'on' => $on('admin.accounting.expense.*'), 'children' => [
            ['label' => 'All Expenses', 'url' => route('admin.accounting.expense.index'),  'on' => $on('admin.accounting.expense.index')],
            ['label' => 'Add Expense',  'url' => route('admin.accounting.expense.create'), 'on' => $on('admin.accounting.expense.create')],
        ]],
        ['label' => 'Customers', 'on' => $on('admin.accounting.customers.*'), 'children' => [
            ['label' => 'Customer Due',    'url' => route('admin.accounting.customers.due'),     'on' => $on('admin.accounting.customers.due')],
            ['label' => 'Payment Receive', 'url' => route('admin.accounting.customers.receive'), 'on' => $on('admin.accounting.customers.receive')],
        ]],
        ['label' => 'Supplier Payment', 'url' => route('admin.accounting.suppliers.payment'), 'on' => $on('admin.accounting.suppliers.*')],
        ['label' => 'Accounts', 'on' => ($on('admin.accounting.accounts.*') || $on('admin.accounting.banks.*')), 'children' => [
            ['label' => 'Cash',  'url' => route('admin.accounting.accounts.show', 'cash'),  'on' => $acct('cash')],
            ['label' => 'Bank',  'url' => route('admin.accounting.banks.index'),  'on' => $on('admin.accounting.banks.*')],
            ['label' => 'bKash', 'url' => route('admin.accounting.accounts.show', 'bkash'), 'on' => $acct('bkash')],
            ['label' => 'Nagad', 'url' => route('admin.accounting.accounts.show', 'nagad'), 'on' => $acct('nagad')],
        ]],
        ['label' => 'Money Transfer', 'url' => route('admin.accounting.transfers.index'), 'on' => $on('admin.accounting.transfers.*')],
        ['label' => 'Transactions / Ledger', 'url' => route('admin.accounting.ledger.index'), 'on' => $on('admin.accounting.ledger.*')],
        ['label' => 'Reports', 'on' => $on('admin.accounting.reports.*'), 'children' => [
            ['label' => 'Profit & Loss',   'url' => route('admin.accounting.reports.profit_loss'),   'on' => $on('admin.accounting.reports.profit_loss')],
            ['label' => 'Income Report',   'url' => route('admin.accounting.reports.income'),        'on' => $on('admin.accounting.reports.income')],
            ['label' => 'Expense Report',  'url' => route('admin.accounting.reports.expense'),       'on' => $on('admin.accounting.reports.expense')],
            ['label' => 'Cash Flow',       'url' => route('admin.accounting.reports.cash_flow'),     'on' => $on('admin.accounting.reports.cash_flow')],
            ['label' => 'Customer Due',    'url' => route('admin.accounting.reports.customer_due'),  'on' => $on('admin.accounting.reports.customer_due')],
        ]],
        ['label' => 'Categories', 'on' => $on('admin.accounting.categories.*'), 'children' => [
            ['label' => 'Income Categories',  'url' => route('admin.accounting.categories.income'),  'on' => $on('admin.accounting.categories.income')],
            ['label' => 'Expense Categories', 'url' => route('admin.accounting.categories.expense'), 'on' => $on('admin.accounting.categories.expense')],
        ]],
        ['label' => 'Accounting Settings', 'url' => route('admin.accounting.settings.edit'), 'on' => $on('admin.accounting.settings.*')],
    ];
?>

<details class="sb-group" <?php echo e($on('admin.accounting.*') ? 'open' : ''); ?>>
  <summary class="sb-link <?php echo e($on('admin.accounting.*') ? 'on' : ''); ?>">
    <span class="sb-ico">💰</span>
    <span class="sb-text">Accounting</span>
    <span class="sb-caret">›</span>
  </summary>
  <div class="sb-sub">
    <?php $__currentLoopData = $acc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if(!empty($s['children'])): ?>
        <details class="sb-nest" <?php echo e(!empty($s['on']) ? 'open' : ''); ?>>
          <summary class="sb-sublink <?php echo e(!empty($s['on']) ? 'on' : ''); ?>">
            <span class="sb-text"><?php echo e($s['label']); ?></span>
            <span class="sb-caret">›</span>
          </summary>
          <div class="sb-nest-items">
            <?php $__currentLoopData = $s['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <a class="sb-sublink <?php echo e(!empty($c['on']) ? 'on' : ''); ?>" href="<?php echo e($c['url']); ?>"><span class="sb-text"><?php echo e($c['label']); ?></span></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </details>
      <?php else: ?>
        <a class="sb-sublink <?php echo e(!empty($s['on']) ? 'on' : ''); ?>" href="<?php echo e($s['url']); ?>"><span class="sb-text"><?php echo e($s['label']); ?></span></a>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</details>

<style>
  .sb-nest > summary { list-style: none; cursor: pointer; display: flex; align-items: center; justify-content: space-between; }
  .sb-nest > summary::-webkit-details-marker { display: none; }
  .sb-nest > summary .sb-caret { transition: transform .15s; }
  .sb-nest[open] > summary .sb-caret { transform: rotate(90deg); }
  .sb-nest-items { padding-left: 14px; }
</style>
<?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/partials/accounting-menu.blade.php ENDPATH**/ ?>