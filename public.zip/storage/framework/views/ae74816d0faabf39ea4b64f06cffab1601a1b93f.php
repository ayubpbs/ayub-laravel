<?php
  $hasOld = !empty($p->old_price);
  $inStock = $p->inStock();
?>
<div class="product-card">
  <a href="<?php echo e($p->url()); ?>" class="product-media">
    <?php if($p->is_upcoming): ?>
      <span class="badge" style="background:#b8860b;">Upcoming..</span>
    <?php elseif(!$inStock): ?>
      <span class="badge" style="background:#c0392b;">Stock out</span>
    <?php elseif($p->badge): ?>
      <span class="badge <?php echo e($hasOld ? 'badge-discount' : 'badge-new'); ?>"><?php echo e($p->badge); ?></span>
    <?php endif; ?>

    <?php if($p->image): ?>
      <img src="<?php echo e(asset('uploads/products/' . $p->image)); ?>" alt="<?php echo e($p->title); ?>" loading="lazy">
    <?php else: ?>
      <span class="emoji"><?php echo e($p->icon ?: '📦'); ?></span>
    <?php endif; ?>
  </a>
  <div class="product-body">
    <span class="product-brand"><?php echo e($p->brand); ?></span>
    <a href="<?php echo e($p->url()); ?>" class="product-title"><?php echo e($p->title); ?></a>
    <div class="rating"><span class="stars"><?php echo e($p->stars()); ?></span> <?php echo e($p->rating); ?> (<?php echo e($p->reviews); ?>)</div>
    <div class="price-row">
      <span class="price-now">৳ <?php echo e(number_format($p->price)); ?></span>
      <?php if($hasOld): ?>
        <span class="price-old">৳ <?php echo e(number_format($p->old_price)); ?></span>
      <?php endif; ?>
    </div>
    <?php if($p->is_upcoming): ?>
      <span class="card-disabled">Coming soon</span>
    <?php elseif(!$inStock): ?>
      <span class="card-disabled">Out of stock</span>
    <?php else: ?>
      <form class="card-actions" action="<?php echo e(route('cart.add', $p->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="quantity" value="1">
        <button type="submit" class="btn-cart">🛒 Add to Cart</button>
        <button type="submit" name="buy_now" value="1" class="btn-buy">Buy Now</button>
      </form>
    <?php endif; ?>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/shop/_card.blade.php ENDPATH**/ ?>