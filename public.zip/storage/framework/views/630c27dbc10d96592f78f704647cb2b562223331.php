<?php $__env->startSection('title', 'Accounting Dashboard'); ?>

<?php $__env->startSection('content'); ?>
  <?php
    $accUrl  = fn ($a) => $a->type === 'bank'
        ? route('admin.accounting.banks.show', $a->id)
        : route('admin.accounting.accounts.show', $a->type);
    $accName = fn ($a) => ($a->type === 'bank' ? '🏦' : (\App\Models\Account::types()[$a->type][1] ?? '')) . ' ' . $a->name;
    $net     = $periodIn - $periodOut;
  ?>

  <h1 class="ad-title">💰 Accounting Dashboard</h1>

  
  <div class="ad-stats">
    <div class="ad-stat ad-stat-hot">
      <span class="n">৳ <?php echo e(number_format($total, 2)); ?></span>
      <span class="l">Total balance (all accounts)</span>
    </div>
    <a class="ad-stat" href="<?php echo e(route('admin.accounting.accounts.show', 'cash')); ?>">
      <span class="n <?php echo e($cash < 0 ? 'ad-red' : ''); ?>">৳ <?php echo e(number_format($cash, 2)); ?></span><span class="l">💵 Cash</span>
    </a>
    <a class="ad-stat" href="<?php echo e(route('admin.accounting.banks.index')); ?>">
      <span class="n <?php echo e($bank < 0 ? 'ad-red' : ''); ?>">৳ <?php echo e(number_format($bank, 2)); ?></span><span class="l">🏦 Banks (<?php echo e($bankCount); ?>)</span>
    </a>
    <a class="ad-stat" href="<?php echo e(route('admin.accounting.accounts.show', 'bkash')); ?>">
      <span class="n <?php echo e($bkash < 0 ? 'ad-red' : ''); ?>">৳ <?php echo e(number_format($bkash, 2)); ?></span><span class="l">📱 bKash</span>
    </a>
    <a class="ad-stat" href="<?php echo e(route('admin.accounting.accounts.show', 'nagad')); ?>">
      <span class="n <?php echo e($nagad < 0 ? 'ad-red' : ''); ?>">৳ <?php echo e(number_format($nagad, 2)); ?></span><span class="l">📲 Nagad</span>
    </a>
  </div>

  
  <div class="ad-tabs">
    <?php $__currentLoopData = $ranges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="<?php echo e(route('admin.accounting.dashboard', ['range' => $key])); ?>" class="<?php echo e($range === $key ? 'on' : ''); ?>"><?php echo e($label); ?></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

  <form class="ad-filter" method="GET" action="<?php echo e(route('admin.accounting.dashboard')); ?>">
    <input type="hidden" name="range" value="custom">
    <label>From <input type="date" name="from" value="<?php echo e($range === 'custom' ? $from : ''); ?>"></label>
    <label>To <input type="date" name="to" value="<?php echo e($range === 'custom' ? $to : ''); ?>"></label>
    <button type="submit" class="ad-btn ad-btn-gray">Show custom period</button>
  </form>

  <p class="ad-muted" style="margin:0 0 12px">Showing: <strong><?php echo e($title); ?></strong> (<?php echo e($span); ?>)</p>

  <div class="ad-stats">
    <div class="ad-stat"><span class="n ad-green">৳ <?php echo e(number_format($periodIn, 2)); ?></span><span class="l">Money in</span></div>
    <div class="ad-stat"><span class="n ad-red">৳ <?php echo e(number_format($periodOut, 2)); ?></span><span class="l">Money out</span></div>
    <div class="ad-stat"><span class="n <?php echo e($net < 0 ? 'ad-red' : 'ad-green'); ?>"><?php echo e($net < 0 ? '−' : ''); ?>৳ <?php echo e(number_format(abs($net), 2)); ?></span><span class="l">Net (<?php echo e($net < 0 ? 'spent more than received' : 'received more than spent'); ?>)</span></div>
  </div>

  
  <section class="ad-card">
    <div class="ad-card-head"><h2>Accounts at a glance</h2><a href="<?php echo e(route('admin.accounting.banks.index')); ?>">Manage banks →</a></div>
    <div class="ad-scroll">
      <table class="ad-table">
        <tr><th>Account</th><th class="r">Balance now</th><th class="r">Money in</th><th class="r">Money out</th></tr>
        <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td>
              <a href="<?php echo e($accUrl($r['account'])); ?>"><strong><?php echo e($accName($r['account'])); ?></strong></a>
              <?php if($r['account']->account_no): ?> <span class="ad-muted">· A/C <?php echo e($r['account']->account_no); ?></span><?php endif; ?>
            </td>
            <td class="r"><span class="<?php echo e($r['balance'] < 0 ? 'ad-red' : ''); ?>">৳ <?php echo e(number_format($r['balance'], 2)); ?></span></td>
            <td class="r"><?php if($r['in'] > 0): ?><span class="ad-green">৳ <?php echo e(number_format($r['in'], 2)); ?></span><?php else: ?> — <?php endif; ?></td>
            <td class="r"><?php if($r['out'] > 0): ?><span class="ad-red">৳ <?php echo e(number_format($r['out'], 2)); ?></span><?php else: ?> — <?php endif; ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr class="ad-tfoot">
          <td>Total</td>
          <td class="r">৳ <?php echo e(number_format($total, 2)); ?></td>
          <td class="r">৳ <?php echo e(number_format($periodIn, 2)); ?></td>
          <td class="r">৳ <?php echo e(number_format($periodOut, 2)); ?></td>
        </tr>
      </table>
    </div>
    <p class="ad-hint">“Money in / out” follows the period chosen above. “Balance now” is the opening balance plus everything entered so far.</p>
  </section>

  <div class="ad-two">
    
    <section class="ad-card">
      <div class="ad-card-head"><h2>Customers &amp; shop payments</h2><a href="<?php echo e(route('admin.payments.index')); ?>">Payments →</a></div>
      <?php if($shop === null): ?>
        <p class="ad-muted">Shop payment data is not available.</p>
      <?php else: ?>
        <table class="ad-table">
          <tr>
            <td>Received from customers <span class="ad-muted">(<?php echo e($title); ?>)</span></td>
            <td class="r"><span class="ad-green">৳ <?php echo e(number_format($shop['received'])); ?></span></td>
          </tr>
          <tr>
            <td><a href="<?php echo e(route('admin.payments.index', ['tab' => 'due'])); ?>">Still to collect</a> <span class="ad-muted">(<?php echo e($shop['due_orders']); ?> orders)</span></td>
            <td class="r"><span class="<?php echo e($shop['due'] > 0 ? 'ad-red' : ''); ?>">৳ <?php echo e(number_format($shop['due'])); ?></span></td>
          </tr>
          <tr>
            <td>To refund <span class="ad-muted">(cancelled / returned)</span></td>
            <td class="r"><span class="<?php echo e($shop['refund_due'] > 0 ? 'ad-red' : ''); ?>">৳ <?php echo e(number_format($shop['refund_due'])); ?></span></td>
          </tr>
        </table>
        <p class="ad-hint">These come from your orders and are shown for information. They are not added to the account balances above.</p>
      <?php endif; ?>
    </section>

    
    <section class="ad-card">
      <div class="ad-card-head"><h2>Last 6 months</h2></div>
      <?php $maxM = max(1, collect($months)->map(fn ($m) => max($m['in'], $m['out']))->max()); ?>
      <div class="ad-scroll">
        <table class="ad-table">
          <tr><th>Month</th><th></th><th class="r">In</th><th class="r">Out</th><th class="r">Net</th></tr>
          <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $mn = $m['in'] - $m['out']; ?>
            <tr>
              <td><?php echo e($m['label']); ?></td>
              <td>
                <div class="ad-bar-bg"><span class="ad-bar-chart" style="width:<?php echo e(round($m['in'] / $maxM * 100)); ?>%;background:#16a34a"></span></div>
                <div class="ad-bar-bg" style="margin-top:3px"><span class="ad-bar-chart" style="width:<?php echo e(round($m['out'] / $maxM * 100)); ?>%;background:#c0392b"></span></div>
              </td>
              <td class="r"><?php echo e(number_format($m['in'], 2)); ?></td>
              <td class="r"><?php echo e(number_format($m['out'], 2)); ?></td>
              <td class="r"><span class="<?php echo e($mn < 0 ? 'ad-red' : 'ad-green'); ?>"><?php echo e($mn < 0 ? '−' : ''); ?><?php echo e(number_format(abs($mn), 2)); ?></span></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
      </div>
      <p class="ad-hint">Green bar = money in, red bar = money out.</p>
    </section>
  </div>

  
  <section class="ad-card">
    <div class="ad-card-head"><h2>Latest entries (all accounts)</h2></div>
    <?php if($recent->isEmpty()): ?>
      <p class="ad-muted">No entries yet. Open an account above and add the first one.</p>
    <?php else: ?>
      <div class="ad-scroll">
        <table class="ad-table">
          <tr><th>Date</th><th>Account</th><th>Note</th><th class="r">Money in</th><th class="r">Money out</th></tr>
          <?php $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($tx->txn_date->format('d M Y')); ?></td>
              <td><a href="<?php echo e($accUrl($tx->account)); ?>"><?php echo e($accName($tx->account)); ?></a></td>
              <td><?php echo e($tx->note ?: '—'); ?></td>
              <td class="r"><?php if($tx->isIn()): ?><span class="ad-green">৳ <?php echo e(number_format((float) $tx->amount, 2)); ?></span><?php else: ?> — <?php endif; ?></td>
              <td class="r"><?php if(!$tx->isIn()): ?><span class="ad-red">৳ <?php echo e(number_format((float) $tx->amount, 2)); ?></span><?php else: ?> — <?php endif; ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
      </div>
    <?php endif; ?>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/accounting/dashboard.blade.php ENDPATH**/ ?>