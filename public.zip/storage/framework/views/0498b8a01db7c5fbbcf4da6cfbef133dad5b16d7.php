<div class="ad-tabs">
  <?php $__currentLoopData = $ranges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(route($route, ['range' => $key])); ?>" class="<?php echo e($range === $key ? 'on' : ''); ?>"><?php echo e($label); ?></a>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<form class="ad-filter" method="GET" action="<?php echo e(route($route)); ?>">
  <input type="hidden" name="range" value="custom">
  <label>From <input type="date" name="from" value="<?php echo e($range === 'custom' ? $from : ''); ?>"></label>
  <label>To <input type="date" name="to" value="<?php echo e($range === 'custom' ? $to : ''); ?>"></label>
  <button type="submit" class="ad-btn ad-btn-gray">Show custom period</button>
</form>

<p class="ad-muted" style="margin:0 0 12px">Showing: <strong><?php echo e($title); ?></strong> (<?php echo e($span); ?>)</p>
<?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/accounting/reports/_period.blade.php ENDPATH**/ ?>