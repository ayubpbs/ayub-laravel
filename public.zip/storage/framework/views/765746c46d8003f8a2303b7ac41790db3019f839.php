<?php $__env->startSection('title', 'Order #' . $order->id); ?>

<?php $__env->startSection('content'); ?>
  <p class="ad-crumbs"><a href="<?php echo e(route('admin.orders.index')); ?>">← All orders</a></p>
  <h1 class="ad-title">Order #<?php echo e($order->id); ?> <span class="ad-st st-<?php echo e($order->status); ?>"><?php echo e($order->statusLabel()); ?></span></h1>

  <div class="ad-two">
    <section class="ad-card">
      <h2>Customer details</h2>
      <dl class="ad-dl">
        <dt>Name</dt><dd><?php echo e($order->name); ?></dd>
        <dt>Mobile</dt><dd><a href="tel:<?php echo e($order->phone); ?>"><?php echo e($order->phone); ?></a> · <a class="ad-link" href="<?php echo e(route('admin.customers.show', $order->phone)); ?>">Customer history</a></dd>
        <dt>Address</dt><dd><?php echo e($order->address); ?></dd>
        <?php if($order->note): ?>
          <dt>Note</dt><dd><?php echo e($order->note); ?></dd>
        <?php endif; ?>
        <dt>Order time</dt><dd><?php echo e($order->created_at->format('d M Y, h:i A')); ?></dd>
        <dt>Payment</dt><dd>Cash on delivery</dd>
      </dl>
    </section>

    <section class="ad-card">
      <h2>Change status</h2>
      <?php if($order->isLocked()): ?>
        <p class="ad-muted">This order is <?php echo e(strtolower($order->statusLabel())); ?>, so its status can no longer be changed.</p>
      <?php else: ?>
        <form action="<?php echo e(route('admin.orders.status', $order->id)); ?>" method="POST" class="ad-form">
          <?php echo csrf_field(); ?>
          <select name="status">
            <?php $__currentLoopData = \App\Models\Order::statuses(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($key); ?>" <?php echo e($order->status === $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <button type="submit" class="ad-btn">Save</button>
        </form>
        <p class="ad-hint">Choosing "Cancelled" or "Returned" puts the products back in stock, and the status cannot be changed afterwards.</p>
      <?php endif; ?>
    </section>
  </div>

  <?php
    $net  = $order->netPaid();
    $due  = $order->dueAmount();
    $inv  = $order->invoice;
  ?>
  <section class="ad-card">
    <div class="ad-card-head">
      <h2>Payment <span class="ad-st <?php echo e(\App\Models\Order::paymentBadge($order->paymentStatus())); ?>"><?php echo e($order->paymentLabel()); ?></span></h2>
      <?php if($inv): ?>
        <a href="<?php echo e(route('admin.invoices.show', $inv->id)); ?>" target="_blank">🖨 Invoice <?php echo e($inv->number()); ?></a>
      <?php endif; ?>
    </div>

    <dl class="ad-dl">
      <dt>Order total</dt><dd>৳ <?php echo e(number_format($order->total)); ?></dd>
      <dt>Received</dt><dd>৳ <?php echo e(number_format($net)); ?></dd>
      <dt><?php echo e($order->isLocked() ? 'To refund' : 'Due'); ?></dt>
      <dd><strong class="<?php echo e(($order->isLocked() ? $net : $due) > 0 ? 'ad-red' : ''); ?>">৳ <?php echo e(number_format($order->isLocked() ? max(0, $net) : $due)); ?></strong></dd>
    </dl>

    <?php if($order->payments->isNotEmpty()): ?>
      <div class="ad-scroll" style="margin-top:12px">
        <table class="ad-table">
          <tr><th>Date</th><th>Method</th><th>Transaction</th><th class="r">Amount</th><th></th></tr>
          <?php $__currentLoopData = $order->payments->sortBy('paid_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($p->paid_at->format('d M Y, h:i A')); ?></td>
              <td><?php echo e($p->methodLabel()); ?> <?php if($p->isRefund()): ?><span class="ad-st st-returned">Refund</span><?php endif; ?></td>
              <td><?php echo e($p->trx_id ?: '—'); ?><?php if($p->note): ?><br><small class="ad-muted"><?php echo e($p->note); ?></small><?php endif; ?></td>
              <td class="r <?php echo e($p->isRefund() ? 'ad-red' : ''); ?>"><?php echo e($p->isRefund() ? '−' : ''); ?>৳ <?php echo e(number_format($p->amount)); ?></td>
              <td>
                <form action="<?php echo e(route('admin.payments.destroy', $p->id)); ?>" method="POST" onsubmit="return confirm('Delete this payment record?');">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="ad-link ad-del">Delete</button>
                </form>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
      </div>
    <?php endif; ?>

    <div class="ad-submit" style="margin-top:12px">
      <?php if(!$order->isLocked() && $due > 0): ?>
        <form action="<?php echo e(route('admin.payments.collect', $order->id)); ?>" method="POST" onsubmit="return confirm('Record ৳ <?php echo e(number_format($due)); ?> as cash on delivery collected?');">
          <?php echo csrf_field(); ?>
          <button type="submit" class="ad-btn">✔ Mark fully paid (cash on delivery)</button>
        </form>
      <?php endif; ?>
      <?php if(!$order->isLocked() || $net > 0): ?>
        <a class="ad-btn ad-btn-gray" href="<?php echo e(route('admin.payments.create', ['order' => $order->id])); ?>">Record payment / refund</a>
      <?php endif; ?>
      <?php if(!$inv && !$order->isLocked()): ?>
        <form action="<?php echo e(route('admin.invoices.generate', $order->id)); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <button type="submit" class="ad-btn ad-btn-gray">Create invoice</button>
        </form>
      <?php endif; ?>
    </div>
  </section>

  <section class="ad-card">
    <h2>Courier</h2>
    <?php if($order->consignment_id): ?>
      <dl class="ad-dl">
        <dt>Courier</dt><dd>Steadfast</dd>
        <dt>Consignment</dt><dd><?php echo e($order->consignment_id); ?></dd>
        <dt>Tracking code</dt><dd><?php echo e($order->tracking_code ?: '—'); ?></dd>
        <dt>Courier status</dt><dd><span class="ad-st <?php echo e(\App\Support\Steadfast::badge($order->courier_status)); ?>"><?php echo e(\App\Support\Steadfast::label($order->courier_status)); ?></span></dd>
        <dt>Sent</dt><dd><?php echo e(optional($order->courier_sent_at)->format('d M Y, h:i A')); ?></dd>
      </dl>
      <form action="<?php echo e(route('admin.courier.refresh', $order->id)); ?>" method="POST" style="margin-top:12px">
        <?php echo csrf_field(); ?>
        <button type="submit" class="ad-btn ad-btn-gray">⟳ Refresh courier status</button>
      </form>
    <?php elseif($order->status === 'confirmed'): ?>
      <p class="ad-muted">Not sent to a courier yet.</p>
      <form action="<?php echo e(route('admin.courier.send', $order->id)); ?>" method="POST" onsubmit="return confirm('Send order #<?php echo e($order->id); ?> to Steadfast now?');">
        <?php echo csrf_field(); ?>
        <button type="submit" class="ad-btn">🚚 Send to Steadfast</button>
      </form>
    <?php else: ?>
      <p class="ad-muted">An order can be sent to Steadfast once it is "Confirmed".</p>
    <?php endif; ?>
  </section>

  <section class="ad-card">
    <h2>Items</h2>
    <div class="ad-scroll">
      <table class="ad-table">
        <tr><th>Product</th><th>Price</th><th>Quantity</th><th class="r">Total</th></tr>
        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($item->title); ?></td>
            <td>৳ <?php echo e(number_format($item->price)); ?></td>
            <td><?php echo e($item->quantity); ?></td>
            <td class="r">৳ <?php echo e(number_format($item->line_total)); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr><td colspan="3" class="r">Subtotal</td><td class="r">৳ <?php echo e(number_format($order->subtotal)); ?></td></tr>
        <tr><td colspan="3" class="r">Delivery charge</td><td class="r">৳ <?php echo e(number_format($order->delivery_charge)); ?></td></tr>
        <tr class="ad-total"><td colspan="3" class="r">Total</td><td class="r">৳ <?php echo e(number_format($order->total)); ?></td></tr>
      </table>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/orders/show.blade.php ENDPATH**/ ?>