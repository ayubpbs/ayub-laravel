
<?php
  $rs   = $product->reviewStats();
  $list = $product->approvedReviews(20);
?>

<?php if(session('review_sent') || $errors->any() || session('error')): ?>
  <span data-pd-open-reviews hidden></span>
<?php endif; ?>

<?php if(session('review_sent')): ?>
  <div class="flash flash-ok" role="status"><?php echo e(session('review_sent')); ?></div>
<?php endif; ?>
<?php if(session('error')): ?>
  <div class="flash flash-err" role="alert"><?php echo e(session('error')); ?></div>
<?php endif; ?>

<div class="pd-rev-top">
  <div class="pd-rev-sum">
    <?php if($rs['count'] > 0): ?>
      <div class="pd-rev-avg"><?php echo e(number_format($rs['avg'], 1)); ?></div>
      <div class="stars" aria-hidden="true"><?php echo e(str_repeat('★', (int) round($rs['avg'])) . str_repeat('☆', 5 - (int) round($rs['avg']))); ?></div>
      <div class="pd-muted"><?php echo e($rs['count']); ?> <?php echo e($rs['count'] == 1 ? 'review' : 'reviews'); ?></div>
    <?php else: ?>
      <div class="pd-muted">No reviews yet.<br>Be the first to review this product.</div>
    <?php endif; ?>
  </div>

  <?php if($rs['count'] > 0): ?>
    <div class="pd-rev-bars">
      <?php $__currentLoopData = [5, 4, 3, 2, 1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $star): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $pct = $rs['count'] ? round($rs['dist'][$star] / $rs['count'] * 100) : 0; ?>
        <div class="pd-rev-bar">
          <span><?php echo e($star); ?> ★</span>
          <div class="pd-rev-track"><div style="width:<?php echo e($pct); ?>%"></div></div>
          <span class="pd-muted"><?php echo e($rs['dist'][$star]); ?></span>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  <?php endif; ?>
</div>

<?php if($list->isNotEmpty()): ?>
  <ul class="pd-rev-list">
    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li>
        <div class="pd-rev-head">
          <span class="stars" aria-label="<?php echo e($r->rating); ?> out of 5 stars"><?php echo e($r->stars()); ?></span>
          <strong><?php echo e($r->name); ?></strong>
          <span class="pd-muted"><?php echo e($r->created_at->format('d M Y')); ?></span>
        </div>
        <?php if($r->comment): ?>
          <p class="pd-rev-text"><?php echo nl2br(e($r->comment)); ?></p>
        <?php endif; ?>
      </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
<?php endif; ?>

<form class="pd-rev-form" method="POST" action="<?php echo e(route('product.review.store', $product->id)); ?>">
  <?php echo csrf_field(); ?>
  <h4>Write a review</h4>

  <?php if($errors->any()): ?>
    <div class="flash flash-err" role="alert">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><?php echo e($e); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  <?php endif; ?>

  <fieldset class="pd-starinput">
    <legend>Your rating *</legend>
    <div class="pd-starinput-row">
      <?php for($i = 5; $i >= 1; $i--): ?>
        <input type="radio" name="rating" id="pd-star-<?php echo e($i); ?>" value="<?php echo e($i); ?>" <?php echo e((int) old('rating') === $i ? 'checked' : ''); ?> required>
        <label for="pd-star-<?php echo e($i); ?>" title="<?php echo e($i); ?> <?php echo e($i == 1 ? 'star' : 'stars'); ?>"><span class="pd-sr"><?php echo e($i); ?> <?php echo e($i == 1 ? 'star' : 'stars'); ?></span>★</label>
      <?php endfor; ?>
    </div>
  </fieldset>

  <label class="pd-field">Your name *
    <input type="text" name="name" value="<?php echo e(old('name')); ?>" maxlength="80" required autocomplete="name">
  </label>
  <label class="pd-field">Your review <small class="pd-muted">(optional)</small>
    <textarea name="comment" rows="4" maxlength="1000"><?php echo e(old('comment')); ?></textarea>
  </label>

  
  <div class="pd-hp" aria-hidden="true">
    <label>Website <input type="text" name="website" tabindex="-1" autocomplete="off"></label>
  </div>

  <button type="submit" class="btn-primary pd-btn pd-rev-submit">Submit review</button>
  <p class="pd-muted pd-rev-note">Your review will be shown after it is approved.</p>
</form>
<?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/shop/product/_reviews.blade.php ENDPATH**/ ?>