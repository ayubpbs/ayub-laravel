<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex,nofollow">
  <title>Admin Login — <?php echo e(config('shop.name')); ?></title>
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/admin.css')); ?>">
</head>
<body class="ad-login-body">
  <div class="ad-login">
    <h1>⚙️ <?php echo e(config('shop.name')); ?></h1>
    <p class="ad-muted">Admin login</p>

    <?php if(session('error')): ?>
      <div class="ad-flash ad-err"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <?php if($disabled): ?>
      <div class="ad-flash ad-warn">
        <strong>The admin panel is not enabled yet.</strong><br>
        Add these two lines at the end of your project's <code>.env</code> file:
        <pre>ADMIN_USER=admin
ADMIN_PASSWORD=a_strong_password_here</pre>
        Then stop <code>php artisan serve</code>, start it again and refresh this page.
      </div>
    <?php else: ?>
      <form action="<?php echo e(route('admin.login.submit')); ?>" method="POST" class="ad-form">
        <?php echo csrf_field(); ?>
        <label>Username
          <input type="text" name="username" value="<?php echo e(old('username')); ?>" required autofocus autocomplete="username">
        </label>
        <label>Password
          <input type="password" name="password" required autocomplete="current-password">
        </label>
        <button type="submit" class="ad-btn ad-btn-block">Login</button>
      </form>
    <?php endif; ?>
  </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/login.blade.php ENDPATH**/ ?>