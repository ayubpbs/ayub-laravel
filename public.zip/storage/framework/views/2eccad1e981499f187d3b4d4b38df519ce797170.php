
<?php
  $max      = max(1, (int) $product->stock_quantity);
  $phone    = trim((string) config('shop.phone'));
  $waMsg    = "Hello, I'm interested in: {$product->title} ({$url})";
  $waLink   = \App\Models\Setting::whatsappLink($waMsg);
  if (!$waLink) {
      $waNum = preg_replace('/\D+/', '', (string) config('shop.whatsapp_number'));
      $waLink = $waNum !== '' ? 'https://wa.me/' . $waNum . '?text=' . rawurlencode($waMsg) : null;
  }
  $delivery     = (int) config('shop.delivery_charge', 0);
  $warrantyOn   = \App\Models\Setting::bool('warranty_enabled', false);
  $warrantyDays = (int) \App\Models\Setting::get('warranty_days', 0);
?>

<div class="pd-info">
  <?php if($product->brand): ?>
    <a class="pd-brand" href="<?php echo e(route('category.index', ['q' => $product->brand])); ?>"><?php echo e($product->brand); ?></a>
  <?php endif; ?>
  <h1 class="pd-title"><?php echo e($product->title); ?></h1>

  <div class="pd-rating">
    <?php if((int) $product->reviews > 0): ?>
      <span class="stars" aria-hidden="true"><?php echo e($product->stars()); ?></span>
      <a href="#reviews" data-pd-goto-reviews><?php echo e($product->rating); ?> · <?php echo e($product->reviews); ?> <?php echo e($product->reviews == 1 ? 'review' : 'reviews'); ?></a>
    <?php elseif(\App\Models\ProductReview::available()): ?>
      <a class="pd-muted" href="#reviews" data-pd-goto-reviews>No reviews yet — write the first one</a>
    <?php else: ?>
      <span class="pd-muted">No reviews yet</span>
    <?php endif; ?>
  </div>

  <div class="pd-price">
    <span class="pd-price-now">৳ <?php echo e(number_format($product->price)); ?></span>
    <?php if($product->discountPercent() > 0): ?>
      <span class="pd-price-old">৳ <?php echo e(number_format($product->old_price)); ?></span>
      <span class="pd-save">Save ৳ <?php echo e(number_format($product->savings())); ?> (<?php echo e($product->discountPercent()); ?>%)</span>
    <?php endif; ?>
  </div>

  <p class="pd-stock pd-stock-<?php echo e($state); ?>">
    <?php if($state === 'upcoming'): ?> ⏳ Coming soon
    <?php elseif($state === 'out'): ?> ✘ Out of stock
    <?php elseif($state === 'low'): ?> ⚠ Only <?php echo e($product->stock_quantity); ?> left in stock
    <?php else: ?> ✔ In stock
    <?php endif; ?>
  </p>

  <?php if($product->hasShortDescription()): ?>
    <div class="pd-short pd-prose"><?php echo $product->shortDescriptionHtml(); ?></div>
  <?php elseif($product->summary(220) !== ''): ?>
    <p class="pd-summary"><?php echo e($product->summary(220)); ?></p>
  <?php endif; ?>

  <?php if($buyable): ?>
    <form id="pd-buy-form" class="buy-form pd-buy" action="<?php echo e(route('cart.add', $product->id)); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <div class="pd-qty-row">
        <span class="pd-label" id="pd-qty-label">Quantity</span>
        <div class="pd-qty" data-pd-qty data-max="<?php echo e($max); ?>" data-price="<?php echo e((int) $product->price); ?>" role="group" aria-labelledby="pd-qty-label">
          <button type="button" data-step="-1" aria-label="Decrease quantity">−</button>
          <input type="number" name="quantity" value="1" min="1" max="<?php echo e($max); ?>" inputmode="numeric" aria-label="Quantity">
          <button type="button" data-step="1" aria-label="Increase quantity">+</button>
        </div>
        <span class="pd-total">Total: <strong>৳ <span data-pd-total><?php echo e(number_format($product->price)); ?></span></strong></span>
      </div>

      <div class="buy-actions pd-actions" data-pd-actions>
        <button type="submit" class="btn-outline pd-btn">🛒 Add to Cart</button>
        <button type="submit" name="buy_now" value="1" class="btn-primary pd-btn">Buy Now</button>
      </div>
    </form>
  <?php elseif($state === 'upcoming'): ?>
    <p class="note">This product is coming soon. Contact us to ask about availability.</p>
  <?php else: ?>
    <p class="note">Sorry, this product is currently out of stock. Contact us to ask when it will be back.</p>
  <?php endif; ?>

  <?php if($waLink || $phone !== ''): ?>
    <div class="pd-contact">
      <?php if($phone !== ''): ?>
        <a class="btn-small pd-contact-btn" href="tel:<?php echo e($phone); ?>">📞 Call <?php echo e($phone); ?></a>
      <?php endif; ?>
      <?php if($waLink): ?>
        <a class="btn-small pd-contact-btn" href="<?php echo e($waLink); ?>" target="_blank" rel="noopener noreferrer">💬 Ask on WhatsApp</a>
      <?php endif; ?>
    </div>
  <?php endif; ?>

  <ul class="pd-trust">
    <li>🚚 <?php echo e($delivery > 0 ? 'Delivery charge ৳ ' . number_format($delivery) : 'Free delivery'); ?></li>
    <?php if($warrantyOn && $warrantyDays > 0): ?>
      <li>🛡️ <?php echo e($warrantyDays); ?>-day warranty</li>
    <?php endif; ?>
  </ul>
</div>
<?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/shop/product/_buybox.blade.php ENDPATH**/ ?>