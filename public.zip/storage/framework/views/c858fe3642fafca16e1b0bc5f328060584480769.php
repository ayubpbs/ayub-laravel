<?php
    $tabs = [
        'cash'  => ['💵', 'Cash',  route('admin.accounting.accounts.show', 'cash')],
        'bank'  => ['🏦', 'Bank',  route('admin.accounting.banks.index')],
        'bkash' => ['📱', 'bKash', route('admin.accounting.accounts.show', 'bkash')],
        'nagad' => ['📲', 'Nagad', route('admin.accounting.accounts.show', 'nagad')],
    ];
?>
<div class="ad-tabs">
  <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e($t[2]); ?>" class="<?php echo e($key === $active ? 'on' : ''); ?>"><?php echo e($t[0]); ?> <?php echo e($t[1]); ?></a>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/accounting/accounts/_tabs.blade.php ENDPATH**/ ?>