<?php $__env->startSection('title', 'Checkout — ' . config('shop.name')); ?>

<?php $__env->startSection('content'); ?>
  <section class="section">
    <p class="crumbs"><a href="<?php echo e(route('cart.index')); ?>">← Back to cart</a></p>
    <h1 class="page-title">Complete your order</h1>

    <?php if($errors->any()): ?>
      <div class="flash flash-err">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div><?php echo e($e); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    <?php endif; ?>

    <div class="cart-wrap">
      <form class="checkout-form" action="<?php echo e(route('checkout.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <label>Your name *
          <input type="text" name="name" value="<?php echo e(old('name')); ?>" required maxlength="100" autocomplete="name">
        </label>

        <label>Mobile number *
          <input type="tel" name="phone" value="<?php echo e(old('phone')); ?>" required placeholder="01XXXXXXXXX" autocomplete="tel">
        </label>

        <label>Delivery address *
          <textarea name="address" rows="3" required maxlength="500" placeholder="House/road, area, thana, district"><?php echo e(old('address')); ?></textarea>
        </label>

        <label>Anything else we should know? (optional)
          <textarea name="note" rows="2" maxlength="500"><?php echo e(old('note')); ?></textarea>
        </label>

        <p class="pay-note">💵 Payment: Cash on delivery (pay when you receive the product)</p>

        <button type="submit" class="btn-primary btn-block">✔ Place Order</button>
      </form>

      <aside class="summary">
        <h2>Your Order</h2>
        <?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="sum-row">
            <span><?php echo e($line['product']->title); ?> × <?php echo e($line['qty']); ?></span>
            <span>৳ <?php echo e(number_format($line['total'])); ?></span>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <hr>
        <div class="sum-row"><span>Subtotal</span><span>৳ <?php echo e(number_format($subtotal)); ?></span></div>
        <div class="sum-row"><span>Delivery charge</span><span>৳ <?php echo e(number_format($delivery)); ?></span></div>
        <div class="sum-row sum-total"><span>Total</span><span>৳ <?php echo e(number_format($total)); ?></span></div>
      </aside>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/checkout/show.blade.php ENDPATH**/ ?>