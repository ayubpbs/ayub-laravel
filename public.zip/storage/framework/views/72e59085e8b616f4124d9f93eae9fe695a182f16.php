<?php $__env->startSection('title', 'Brands'); ?>

<?php $__env->startSection('content'); ?>
  <div class="ad-bar">
    <h1 class="ad-title">Brands</h1>
    <a class="ad-btn" href="<?php echo e(route('admin.brands.create')); ?>">＋ New Brand</a>
  </div>

  <section class="ad-card">
    <?php if($brands->isEmpty()): ?>
      <p class="ad-muted">No brands yet.</p>
    <?php else: ?>
      <div class="ad-scroll">
        <table class="ad-table">
          <tr><th>Order</th><th>Logo</th><th>Name</th><th>Products</th><th></th></tr>
          <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($b->sort_order); ?></td>
              <td class="ad-thumb">
                <?php if($b->logo): ?>
                  <img src="<?php echo e(asset('uploads/brands/' . $b->logo)); ?>" alt="">
                <?php else: ?>
                  <span>🏷️</span>
                <?php endif; ?>
              </td>
              <td><a href="<?php echo e(route('admin.brands.edit', $b->id)); ?>"><strong><?php echo e($b->name); ?></strong></a></td>
              <td><a href="<?php echo e(route('admin.products.index', ['brand' => $b->id])); ?>"><?php echo e($b->products_count); ?></a></td>
              <td class="ad-actions">
                <a class="ad-link" href="<?php echo e(route('admin.brands.edit', $b->id)); ?>">Edit</a>
                <form action="<?php echo e(route('admin.brands.destroy', $b->id)); ?>" method="POST" onsubmit="return confirm('Really delete this brand?');">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="ad-link ad-del">Delete</button>
                </form>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
      </div>
    <?php endif; ?>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/brands/index.blade.php ENDPATH**/ ?>