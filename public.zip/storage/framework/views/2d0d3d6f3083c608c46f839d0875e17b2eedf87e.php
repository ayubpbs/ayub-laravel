<?php $editing = !empty($entry); $heading = $editing ? 'Edit ' . strtolower($k['label']) : $k['add']; ?>
<?php $__env->startSection('title', $heading); ?>

<?php $__env->startSection('content'); ?>
  <p class="ad-crumbs"><a href="<?php echo e(route('admin.accounting.' . $kind . '.index')); ?>">← <?php echo e($k['list']); ?></a></p>
  <h1 class="ad-title"><?php echo e($k['icon']); ?> <?php echo e($heading); ?></h1>

  <section class="ad-card">
    <form class="ad-form" action="<?php echo e($editing ? route('admin.accounting.' . $kind . '.update', $entry->id) : route('admin.accounting.' . $kind . '.store')); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <?php if($editing): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
      <div class="ad-row">
        <label><?php echo e($kind === 'income' ? 'Money goes into' : 'Money is paid from'); ?>

          <select name="account_id" required>
            <option value="">— Choose account —</option>
            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($a['id']); ?>" <?php echo e((string) old('account_id', $editing ? $entry->account_id : '') === (string) $a['id'] ? 'selected' : ''); ?>><?php echo e($a['label']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </label>
        <label>Category <small>(optional)</small>
          <select name="category_id">
            <option value="">— No category —</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($c->id); ?>" <?php echo e((string) old('category_id', $editing ? $entry->category_id : request('category')) === (string) $c->id ? 'selected' : ''); ?>><?php echo e($c->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </label>
      </div>
      <div class="ad-row">
        <label>Amount (৳)
          <input type="number" name="amount" value="<?php echo e(old('amount', $editing ? $entry->amount : '')); ?>" step="0.01" min="0.01" required>
        </label>
        <label>Date
          <input type="date" name="txn_date" id="txnDate" value="<?php echo e(old('txn_date', $editing ? $entry->txn_date->toDateString() : now()->toDateString())); ?>" required>
        </label>
      </div>
      <label>Note <small>(optional)</small>
        <input type="text" name="note" value="<?php echo e(old('note', $editing ? $entry->note : '')); ?>" maxlength="255" placeholder="<?php echo e($kind === 'income' ? 'e.g. Service charge from customer…' : 'e.g. Shop rent for this month…'); ?>">
      </label>
      <div class="ad-submit">
        <button type="submit" class="ad-btn"><?php echo e($editing ? 'Save changes' : 'Save ' . strtolower($k['label'])); ?></button>
        <a class="ad-btn ad-btn-gray" href="<?php echo e(route('admin.accounting.' . $kind . '.index')); ?>">Cancel</a>
      </div>
    </form>
    <?php if($categories->isEmpty()): ?>
      <p class="ad-hint">No <?php echo e(strtolower($k['label'])); ?> category yet. You can <a href="<?php echo e(route('admin.accounting.categories.' . $kind)); ?>">add categories here</a>.</p>
    <?php endif; ?>
    <p class="ad-hint">This entry is also shown on the chosen account's own page and changes its balance.<?php echo e($editing ? ' Saving changes updates the balances of the old and the new account.' : ''); ?></p>
  </section>

  <script>
    // Default the date to the browser's local day (the server clock may be in another time zone)
    (function () {
      var d = document.getElementById('txnDate');
      if (d && !<?php echo e(($editing || old('txn_date')) ? 'true' : 'false'); ?>) {
        d.value = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
      }
    })();
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/accounting/entries/create.blade.php ENDPATH**/ ?>