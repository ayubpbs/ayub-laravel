
<?php
  // Images first, then the YouTube videos
  $items = [];
  foreach ($gallery as $u) {
      $items[] = ['type' => 'image', 'src' => $u];
  }
  foreach ($product->videos() as $v) {
      $items[] = ['type' => 'video', 'thumb' => $v['thumb'], 'hq' => $v['hq'], 'embed' => $v['embed']];
  }
  $first      = $items[0] ?? null;
  $firstIsImg = $first && $first['type'] === 'image';
?>
<div class="pd-media-col" data-pd-gallery data-items="<?php echo e(json_encode($items)); ?>" data-title="<?php echo e($product->title); ?>">
  <div class="pd-media">
    <?php if($product->discountPercent() > 0 && $state !== 'upcoming'): ?>
      <span class="pd-badge">-<?php echo e($product->discountPercent()); ?>%</span>
    <?php elseif($state === 'upcoming'): ?>
      <span class="pd-badge pd-badge-soon">Upcoming</span>
    <?php elseif($state === 'out'): ?>
      <span class="pd-badge pd-badge-out">Stock out</span>
    <?php endif; ?>

    <?php if($first): ?>
      <button type="button" class="pd-zoom" data-pd-zoom aria-label="Enlarge image" <?php if(!$firstIsImg): ?> hidden <?php endif; ?>>
        <img <?php if($firstIsImg): ?> src="<?php echo e($first['src']); ?>" fetchpriority="high" <?php endif; ?> alt="<?php echo e($product->title); ?>" data-pd-main>
        <span class="pd-zoom-hint" aria-hidden="true">🔍 Click to enlarge</span>
      </button>

      <div class="pd-video" data-pd-video <?php if($firstIsImg): ?> hidden <?php endif; ?>>
        <button type="button" class="pd-video-play" data-pd-play aria-label="Play video">
          <img <?php if(!$firstIsImg): ?> src="<?php echo e($first['hq']); ?>" <?php endif; ?> alt="" data-pd-video-thumb>
          <span class="pd-play-icon" aria-hidden="true">▶</span>
        </button>
      </div>

      <?php if(count($items) > 1): ?>
        <button type="button" class="pd-nav pd-prev" data-pd-prev aria-label="Previous">‹</button>
        <button type="button" class="pd-nav pd-next" data-pd-next aria-label="Next">›</button>
        <span class="pd-counter" data-pd-counter aria-live="polite">1 / <?php echo e(count($items)); ?></span>
      <?php endif; ?>
    <?php else: ?>
      <div class="pd-noimg"><span class="emoji"><?php echo e($product->icon ?: '📦'); ?></span></div>
    <?php endif; ?>
  </div>

  <?php if(count($items) > 1): ?>
    <ul class="pd-thumbs" data-pd-thumbs>
      <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
          <button type="button" class="pd-thumb <?php echo e($i === 0 ? 'is-active' : ''); ?>" data-pd-thumb="<?php echo e($i); ?>"
                  aria-label="<?php echo e($it['type'] === 'video' ? 'Show video' : 'Show image'); ?> <?php echo e($i + 1); ?>" <?php if($i === 0): ?> aria-current="true" <?php endif; ?>>
            <img src="<?php echo e($it['type'] === 'video' ? $it['thumb'] : $it['src']); ?>" alt="" loading="lazy">
            <?php if($it['type'] === 'video'): ?><span class="pd-thumb-play" aria-hidden="true">▶</span><?php endif; ?>
          </button>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/shop/product/_gallery.blade.php ENDPATH**/ ?>