<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex,nofollow">
  <title><?php echo $__env->yieldContent('title', 'Admin'); ?> — <?php echo e(config('shop.name')); ?></title>
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/admin.css')); ?>">
</head>
<body class="ad-body">
<div class="ad-shell">
  <?php echo $__env->make('admin.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="ad-content">
    <div class="ad-topbar">
      <button type="button" class="ad-burger" id="sbToggle" aria-label="Menu">☰</button>
      <span class="ad-topbar-title"><?php echo e(config('shop.name')); ?></span>
      <?php $bellCount = \App\Models\AdminNotification::unreadCount(); ?>
      <a class="ad-topbar-bell" href="<?php echo e(route('admin.notifications.index')); ?>" aria-label="Notifications">🔔<?php if($bellCount > 0): ?><span class="sb-badge"><?php echo e($bellCount); ?></span><?php endif; ?></a>
    </div>

    <main class="ad-main">
      <?php if(session('success')): ?>
        <div class="ad-flash ad-ok"><?php echo e(session('success')); ?></div>
      <?php endif; ?>
      <?php if(session('error')): ?>
        <div class="ad-flash ad-err"><?php echo e(session('error')); ?></div>
      <?php endif; ?>
      <?php if($errors->any()): ?>
        <div class="ad-flash ad-err">
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><?php echo e($e); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      <?php endif; ?>

      <?php echo $__env->yieldContent('content'); ?>
    </main>
  </div>
</div>

<script>
  (function () {
    var body = document.body;
    function toggle(open) { body.classList.toggle('sb-open', open); }
    document.getElementById('sbToggle').addEventListener('click', function () { toggle(!body.classList.contains('sb-open')); });
    document.getElementById('sbOverlay').addEventListener('click', function () { toggle(false); });
  })();
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/layout.blade.php ENDPATH**/ ?>