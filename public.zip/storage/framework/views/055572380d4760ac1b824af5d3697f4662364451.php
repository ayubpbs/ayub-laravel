
<?php
  $warrantyOn    = \App\Models\Setting::bool('warranty_enabled', false);
  $warrantyDays  = (int) \App\Models\Setting::get('warranty_days', 0);
  $warrantyTerms = trim((string) \App\Models\Setting::get('warranty_terms', ''));
  $deliveryFee   = (int) config('shop.delivery_charge', 0);
  $specs         = $product->specs();
  $categoryPath  = collect($crumbs)->pluck('label')->implode(' › ');
?>

<div class="pd-tabs" id="reviews" data-pd-tabs>
  <div class="pd-tab-nav" role="tablist" aria-label="Product information">
    <button type="button" role="tab" id="pd-tab-desc" aria-controls="pd-panel-desc" aria-selected="true">Description</button>
    <?php if($specs): ?>
      <button type="button" role="tab" id="pd-tab-specs" aria-controls="pd-panel-specs" aria-selected="false" tabindex="-1">Specifications</button>
    <?php endif; ?>
    <button type="button" role="tab" id="pd-tab-details" aria-controls="pd-panel-details" aria-selected="false" tabindex="-1">Details</button>
    <button type="button" role="tab" id="pd-tab-ship" aria-controls="pd-panel-ship" aria-selected="false" tabindex="-1">Delivery &amp; Warranty</button>
    <?php if(\App\Models\ProductReview::available()): ?>
      <button type="button" role="tab" id="pd-tab-reviews" aria-controls="pd-panel-reviews" aria-selected="false" tabindex="-1">Reviews <?php if((int) $product->reviews > 0): ?>(<?php echo e((int) $product->reviews); ?>)<?php endif; ?></button>
    <?php endif; ?>
  </div>

  <div class="pd-panel" id="pd-panel-desc" role="tabpanel" aria-labelledby="pd-tab-desc">
    <h3>Description</h3>
    <?php if($product->hasDescription()): ?>
      <div class="pd-prose"><?php echo $product->descriptionHtml(); ?></div>
    <?php else: ?>
      <p class="pd-muted">No description has been added for this product yet.</p>
    <?php endif; ?>
  </div>

  <?php if($specs): ?>
    <div class="pd-panel" id="pd-panel-specs" role="tabpanel" aria-labelledby="pd-tab-specs">
      <h3>Specifications</h3>
      <table class="pd-table">
        <tbody>
          <?php $__currentLoopData = $specs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr><th scope="row"><?php echo e($row['name']); ?></th><td><?php echo e($row['value']); ?></td></tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>

  <div class="pd-panel" id="pd-panel-details" role="tabpanel" aria-labelledby="pd-tab-details">
    <h3>Details</h3>
    <table class="pd-table">
      <tbody>
        <tr><th scope="row">Product</th><td><?php echo e($product->title); ?></td></tr>
        <?php if($product->sku): ?><tr><th scope="row">SKU</th><td><?php echo e($product->sku); ?></td></tr><?php endif; ?>
        <?php if($product->brand): ?><tr><th scope="row">Brand</th><td><?php echo e($product->brand); ?></td></tr><?php endif; ?>
        <?php if($categoryPath !== ''): ?><tr><th scope="row">Category</th><td><?php echo e($categoryPath); ?></td></tr><?php endif; ?>
        <tr><th scope="row">Availability</th><td>
          <?php if($state === 'upcoming'): ?> Coming soon
          <?php elseif($state === 'out'): ?> Out of stock
          <?php elseif($state === 'low'): ?> Low stock (<?php echo e($product->stock_quantity); ?> left)
          <?php else: ?> In stock
          <?php endif; ?>
        </td></tr>
        <?php if((int) $product->reviews > 0): ?><tr><th scope="row">Rating</th><td><?php echo e($product->rating); ?> / 5 (<?php echo e($product->reviews); ?>)</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>

  <div class="pd-panel" id="pd-panel-ship" role="tabpanel" aria-labelledby="pd-tab-ship">
    <h3>Delivery &amp; Warranty</h3>
    <p><strong>Delivery:</strong> <?php echo e($deliveryFee > 0 ? 'Delivery charge is ৳ ' . number_format($deliveryFee) . ' per order.' : 'No delivery charge.'); ?></p>
    <?php if($warrantyOn && $warrantyDays > 0): ?>
      <p><strong>Warranty:</strong> <?php echo e($warrantyDays); ?> days.</p>
    <?php endif; ?>
    <?php if($warrantyOn && $warrantyTerms !== ''): ?>
      <div class="pd-prose"><?php echo nl2br(e($warrantyTerms)); ?></div>
    <?php endif; ?>
  </div>

  <?php if(\App\Models\ProductReview::available()): ?>
    <div class="pd-panel" id="pd-panel-reviews" role="tabpanel" aria-labelledby="pd-tab-reviews">
      <h3>Reviews</h3>
      <?php echo $__env->make('shop.product._reviews', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/shop/product/_tabs.blade.php ENDPATH**/ ?>