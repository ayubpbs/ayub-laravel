<?php $__env->startSection('title', $k['list']); ?>

<?php $__env->startSection('content'); ?>
  <div class="ad-bar">
    <h1 class="ad-title"><?php echo e($k['icon']); ?> <?php echo e($k['list']); ?></h1>
    <a class="ad-btn" href="<?php echo e(route('admin.accounting.' . $kind . '.create')); ?>">＋ <?php echo e($k['add']); ?></a>
  </div>

  <div class="ad-stats">
    <div class="ad-stat"><span class="n <?php echo e($kind === 'income' ? 'ad-green' : 'ad-red'); ?>">৳ <?php echo e(number_format($monthTotal, 2)); ?></span><span class="l">This month</span></div>
    <div class="ad-stat"><span class="n">৳ <?php echo e(number_format($allTotal, 2)); ?></span><span class="l">All time</span></div>
  </div>

  <section class="ad-card">
    <form class="ad-filter" method="GET" action="<?php echo e(route('admin.accounting.' . $kind . '.index')); ?>">
      <label>From <input type="date" name="from" value="<?php echo e($f['from']); ?>"></label>
      <label>To <input type="date" name="to" value="<?php echo e($f['to']); ?>"></label>
      <select name="account">
        <option value="">All accounts</option>
        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($a['id']); ?>" <?php echo e((string) $f['account'] === (string) $a['id'] ? 'selected' : ''); ?>><?php echo e($a['label']); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <select name="category">
        <option value="">All categories</option>
        <option value="none" <?php echo e($f['category'] === 'none' ? 'selected' : ''); ?>>No category</option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($c->id); ?>" <?php echo e($f['category'] === (string) $c->id ? 'selected' : ''); ?>><?php echo e($c->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <button type="submit" class="ad-btn ad-btn-gray">Filter</button>
      <?php if($filtered): ?>
        <a class="ad-btn ad-btn-gray" href="<?php echo e(route('admin.accounting.' . $kind . '.index')); ?>">Reset</a>
      <?php endif; ?>
    </form>

    <?php if($entries->isEmpty()): ?>
      <p class="ad-muted">No <?php echo e(strtolower($k['label'])); ?> entries found.</p>
    <?php else: ?>
      <div class="ad-scroll">
        <table class="ad-table">
          <tr><th>Date</th><th>Category</th><th>Account</th><th>Note</th><th class="r">Amount</th><th></th></tr>
          <?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($e->txn_date->format('d M Y')); ?></td>
              <td><?php echo e($e->category->name ?? '—'); ?></td>
              <td><?php echo e($e->account->name ?? '—'); ?><?php if(($e->account->type ?? '') === 'bank' && $e->account->account_no): ?> <span class="ad-muted">(<?php echo e($e->account->account_no); ?>)</span><?php endif; ?></td>
              <td><?php echo e($e->note ?: '—'); ?></td>
              <td class="r"><span class="<?php echo e($kind === 'income' ? 'ad-green' : 'ad-red'); ?>">৳ <?php echo e(number_format((float) $e->amount, 2)); ?></span></td>
              <td class="ad-actions">
                <?php if(empty($e->payment_id)): ?>
                  <a class="ad-link" href="<?php echo e(route('admin.accounting.' . $kind . '.edit', $e->id)); ?>">Edit</a>
                <?php else: ?>
                  <small class="ad-muted" title="Change it on the order's Payments page">Order payment</small>
                <?php endif; ?>
                <form action="<?php echo e(route('admin.accounting.' . $kind . '.destroy', $e->id)); ?>" method="POST" onsubmit="return confirm('Delete this entry? The account balance will change.')">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="ad-link ad-del">Delete</button>
                </form>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php if($filtered): ?>
            <tr class="ad-tfoot">
              <td colspan="4">Total of this filtered list</td>
              <td class="r">৳ <?php echo e(number_format($listTotal, 2)); ?></td>
              <td></td>
            </tr>
          <?php endif; ?>
        </table>
      </div>
      <div class="ad-pager"><?php echo e($entries->links('pagination::simple-default')); ?></div>
    <?php endif; ?>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/accounting/entries/index.blade.php ENDPATH**/ ?>