<?php

use App\Http\Controllers\Admin\CustomerAddressController;
use App\Http\Controllers\Admin\CustomerController;
use App\Http\Controllers\Admin\OrderCreateController;
use App\Http\Middleware\AdminAuth;
use Illuminate\Support\Facades\Route;

// Admin: customers added by hand and their saved addresses. Every route name starts with
// "admin.customers." so the existing "Customers" permission applies (see App\Support\AdminAccess).
Route::prefix('admin')->name('admin.')->middleware(AdminAuth::class)->group(function () {
    Route::get('customers/create', [CustomerController::class, 'create'])->name('customers.create');
    Route::post('customers', [CustomerController::class, 'store'])->name('customers.store');

    $a = CustomerAddressController::class;
    Route::get('customers/{phone}/addresses/create', [$a, 'create'])->where('phone', '[0-9]+')->name('customers.addresses.create');
    Route::post('customers/{phone}/addresses', [$a, 'store'])->where('phone', '[0-9]+')->name('customers.addresses.store');
    Route::get('customers/{phone}/addresses/{id}/edit', [$a, 'edit'])->where('phone', '[0-9]+')->whereNumber('id')->name('customers.addresses.edit');
    Route::put('customers/{phone}/addresses/{id}', [$a, 'update'])->where('phone', '[0-9]+')->whereNumber('id')->name('customers.addresses.update');
    Route::post('customers/{phone}/addresses/{id}/default', [$a, 'makeDefault'])->where('phone', '[0-9]+')->whereNumber('id')->name('customers.addresses.default');
    Route::delete('customers/{phone}/addresses/{id}', [$a, 'destroy'])->where('phone', '[0-9]+')->whereNumber('id')->name('customers.addresses.destroy');

    // Admin: create an order by hand and Reorder (phase 4). The URL is /admin/new-order (not /admin/orders/create)
    // because the existing route admin/orders/{id} would catch "create" first. Names start with "admin.orders."
    // and are mapped to the "orders_create" permission above "admin.orders.*" in App\Support\AdminAccess.
    $o = OrderCreateController::class;
    Route::get('new-order', [$o, 'create'])->name('orders.create');
    Route::get('new-order/customer', [$o, 'lookup'])->name('orders.create.customer');
    Route::get('new-order/products', [$o, 'products'])->name('orders.create.products');
    Route::post('new-order', [$o, 'store'])->name('orders.store');
});
