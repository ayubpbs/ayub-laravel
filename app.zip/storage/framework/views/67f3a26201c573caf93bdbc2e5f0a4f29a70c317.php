<?php $__env->startSection('content'); ?>

  
  <section class="hero-section">
    <div class="hero-grid">
      <div class="hero-main-slider">
        <div class="hero-main-track" id="heroMainTrack">
          <?php $__currentLoopData = [1, 2, 3]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="hero-main-slide" href="#products">
              <?php if(file_exists(public_path("assets/images/hero/slide-{$i}.jpg"))): ?>
                <img src="<?php echo e(asset("assets/images/hero/slide-{$i}.jpg")); ?>" alt="Slide <?php echo e($i); ?>">
              <?php else: ?>
                <div class="hero-ph hero-ph-<?php echo e($i); ?>">
                  <h2><?php echo e(config('shop.name')); ?></h2>
                  <p>Slide <?php echo e($i); ?> — add public/assets/images/hero/slide-<?php echo e($i); ?>.jpg to show an image</p>
                </div>
              <?php endif; ?>
            </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <button class="hero-nav prev" id="heroPrev" aria-label="Previous slide">‹</button>
        <button class="hero-nav next" id="heroNext" aria-label="Next slide">›</button>
        <div class="hero-main-dots" id="heroMainDots"></div>
      </div>
      <div class="hero-side">
        <?php $__currentLoopData = [1, 2]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a class="hero-side-card" href="<?php echo e(route('category.index')); ?>">
            <?php if(file_exists(public_path("assets/images/hero/side-{$i}.jpg"))): ?>
              <img src="<?php echo e(asset("assets/images/hero/side-{$i}.jpg")); ?>" alt="Offer <?php echo e($i); ?>">
            <?php else: ?>
              <div class="hero-ph hero-side-ph-<?php echo e($i); ?>"><p>View all products</p></div>
            <?php endif; ?>
          </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </section>

  
  <section class="section">
    <div class="section-head"><h2>Shop by Category</h2></div>
    <div class="cat-scroll">
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a class="cat-item" href="<?php echo e(route('category.show', $c->id)); ?>">
          <div class="cat-icon">
            <?php if($c->image): ?>
              <img src="<?php echo e(asset('assets/images/categories/' . $c->image)); ?>" alt="<?php echo e($c->label); ?>" loading="lazy">
            <?php else: ?>
              <span><?php echo e($c->icon ?: '📦'); ?></span>
            <?php endif; ?>
          </div>
          <span><?php echo e($c->label); ?></span>
        </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </section>

  
  <section class="section" id="products">
    <div class="section-head">
      <h2>Top Products</h2>
      <a href="<?php echo e(route('category.index')); ?>">View all →</a>
    </div>
    <div class="grid">
      <?php $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo $__env->make('shop._card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </section>

  
  <div class="promo-band">
    <div>
      <h3>Ordering in bulk?</h3>
      <p>Special wholesale prices for contractors and electricians</p>
    </div>
    <a class="btn-primary" href="#contact">Request a Quote</a>
  </div>

  
  <section class="section">
    <div class="section-head">
      <h2>New Products</h2>
      <a href="<?php echo e(route('category.index')); ?>">View all →</a>
    </div>
    <div class="grid">
      <?php $__currentLoopData = $newProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo $__env->make('shop._card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </section>

  
  <?php if($upcomingProducts->isNotEmpty()): ?>
    <section class="section" id="upcoming">
      <div class="section-head"><h2>Coming Soon</h2></div>
      <div class="grid">
        <?php $__currentLoopData = $upcomingProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo $__env->make('shop._card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </section>
  <?php endif; ?>

  
  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $catProducts = $c->products->take(8); ?>
    <?php if($catProducts->isEmpty()) continue; ?>

    <?php
      $catImg = null;
      foreach (['jpg', 'jpeg', 'png', 'webp'] as $ext) {
          if (file_exists(public_path("assets/images/sections/cat-{$c->id}.{$ext}"))) {
              $catImg = "assets/images/sections/cat-{$c->id}.{$ext}";
              break;
          }
      }
    ?>

    <section class="section" id="cat-<?php echo e($c->id); ?>">
      <div class="section-head">
        <h2><?php echo e($c->label); ?></h2>
        <a href="<?php echo e(route('category.show', $c->id)); ?>">View all →</a>
      </div>
      <?php if($catImg): ?>
        <a class="cat-section-banner" href="<?php echo e(route('category.show', $c->id)); ?>">
          <img src="<?php echo e(asset($catImg)); ?>" alt="<?php echo e($c->label); ?>" loading="lazy">
        </a>
      <?php endif; ?>
      <div class="grid">
        <?php $__currentLoopData = $catProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo $__env->make('shop._card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </section>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


  
  <?php echo $__env->make('partials.floating-contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
(function(){
  var track = document.getElementById('heroMainTrack');
  var dotsWrap = document.getElementById('heroMainDots');
  var prevBtn = document.getElementById('heroPrev');
  var nextBtn = document.getElementById('heroNext');
  if(!track || !dotsWrap) return;
  var slides = Array.prototype.slice.call(track.children);
  if(!slides.length) return;

  slides.forEach(function(_, i){
    var b = document.createElement('button');
    b.className = 'hsd-dot' + (i === 0 ? ' active' : '');
    b.type = 'button'; b.dataset.i = i;
    b.setAttribute('aria-label', 'Slide ' + (i + 1));
    dotsWrap.appendChild(b);
  });
  var dots = dotsWrap.querySelectorAll('.hsd-dot');
  var current = 0, timer = null;

  function updateDots(){ dots.forEach(function(d, i){ d.classList.toggle('active', i === current); }); }
  function goTo(i){
    current = (i + slides.length) % slides.length;
    track.scrollTo({ left: current * track.clientWidth, behavior: 'smooth' });
    updateDots();
  }
  function startAutoplay(){ stopAutoplay(); timer = setInterval(function(){ goTo(current + 1); }, 4000); }
  function stopAutoplay(){ if(timer){ clearInterval(timer); timer = null; } }

  prevBtn.addEventListener('click', function(){ goTo(current - 1); startAutoplay(); });
  nextBtn.addEventListener('click', function(){ goTo(current + 1); startAutoplay(); });
  dots.forEach(function(d){ d.addEventListener('click', function(){ goTo(parseInt(d.dataset.i, 10)); startAutoplay(); }); });

  var ticking = false;
  track.addEventListener('scroll', function(){
    if(ticking) return; ticking = true;
    requestAnimationFrame(function(){
      current = Math.round(track.scrollLeft / track.clientWidth);
      updateDots(); ticking = false;
    });
  });
  track.addEventListener('touchstart', stopAutoplay, {passive:true});
  track.addEventListener('touchend', startAutoplay, {passive:true});
  window.addEventListener('resize', function(){ track.scrollTo({ left: current * track.clientWidth, behavior: 'auto' }); });
  if(slides.length > 1) startAutoplay();
})();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/shop/home.blade.php ENDPATH**/ ?>