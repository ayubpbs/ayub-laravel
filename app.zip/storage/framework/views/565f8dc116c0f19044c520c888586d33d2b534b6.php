
<form class="ad-card ad-form" method="POST" action="<?php echo e(route('admin.payments.store')); ?>">
  <?php echo csrf_field(); ?>
  <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
  <input type="hidden" name="return" value="<?php echo e($return); ?>">

  <div class="ad-row">
    <label>Type
      <select name="type" id="payType_<?php echo e($order->id); ?>">
        <?php if(!$locked && $due > 0): ?>
          <option value="payment" <?php echo e(old('type') === 'payment' ? 'selected' : ''); ?>>Payment received</option>
        <?php endif; ?>
        <?php if($net > 0): ?>
          <option value="refund" <?php echo e(old('type', $locked ? 'refund' : '') === 'refund' ? 'selected' : ''); ?>>Refund given back</option>
        <?php endif; ?>
      </select>
    </label>
    <label>Method
      <select name="method">
        <?php $__currentLoopData = \App\Models\Payment::methods(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($k); ?>" <?php echo e(old('method', 'bkash') === $k ? 'selected' : ''); ?>><?php echo e($label); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </label>
    <label>Amount (৳)
      <input type="number" name="amount" min="1" value="<?php echo e(old('amount', $locked ? $net : $due)); ?>" required>
    </label>
  </div>

  <div class="ad-row">
    <label>Transaction ID <small>(required for bKash / Nagad / Rocket payments)</small>
      <input type="text" name="trx_id" value="<?php echo e(old('trx_id')); ?>" maxlength="100" autocomplete="off">
    </label>
    <label>Sender number <small>(optional)</small>
      <input type="text" name="sender_number" value="<?php echo e(old('sender_number')); ?>" maxlength="20">
    </label>
    <label>Date &amp; time <small>(blank = now)</small>
      <input type="datetime-local" name="paid_at" value="<?php echo e(old('paid_at')); ?>">
    </label>
  </div>

  <label>Note <small>(optional)</small>
    <input type="text" name="note" value="<?php echo e(old('note')); ?>" maxlength="255">
  </label>

  <div class="ad-submit">
    <button type="submit" class="ad-btn">Save</button>
  </div>
</form>
<?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/payments/_form.blade.php ENDPATH**/ ?>