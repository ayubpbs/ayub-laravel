<?php $editing = $address->exists; ?>

<?php $__env->startSection('title', $editing ? 'Edit Address' : 'Add Address'); ?>

<?php $__env->startSection('content'); ?>
  <p class="ad-crumbs"><a href="<?php echo e(route('admin.customers.show', $phone)); ?>">← Back to customer <?php echo e($phone); ?></a></p>
  <h1 class="ad-title"><?php echo e($editing ? 'Edit Address' : 'Add Address'); ?></h1>

  <form class="ad-card ad-form" method="POST"
        action="<?php echo e($editing ? route('admin.customers.addresses.update', [$phone, $address->id]) : route('admin.customers.addresses.store', $phone)); ?>">
    <?php echo csrf_field(); ?>
    <?php if($editing): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

    <div class="ad-row">
      <label>Recipient name *
        <input type="text" name="recipient_name" value="<?php echo e(old('recipient_name', $address->recipient_name)); ?>" required maxlength="100">
      </label>
      <label>Recipient mobile *
        <input type="text" name="phone" value="<?php echo e(old('phone', $address->phone)); ?>" required maxlength="30" inputmode="tel">
      </label>
    </div>

    <div class="ad-row">
      <label>District *
        <select name="district" id="f-district" required><option value="">Select district</option></select>
      </label>
      <label>Upazila / Thana *
        <select name="upazila" id="f-upazila" required disabled><option value="">Select district first</option></select>
      </label>
      <label>City / Town *
        <input type="text" name="city" value="<?php echo e(old('city', $address->city)); ?>" required maxlength="100">
      </label>
    </div>

    <label>Full address *
      <textarea name="address" rows="2" required maxlength="500"><?php echo e(old('address', $address->address)); ?></textarea>
    </label>

    <label>Landmark / delivery instructions <small>(optional)</small>
      <input type="text" name="landmark" value="<?php echo e(old('landmark', $address->landmark)); ?>" maxlength="255">
    </label>

    <label class="ad-check">
      <input type="checkbox" name="is_default" value="1" <?php echo e(old('is_default', $address->is_default) ? 'checked' : ''); ?> <?php echo e($editing && $address->is_default ? 'disabled' : ''); ?>>
      Use as the default address
      <?php if($editing && $address->is_default): ?><small>(this is the default now; to change it, make another address the default)</small><?php endif; ?>
    </label>

    <div class="ad-submit">
      <button type="submit" class="ad-btn"><?php echo e($editing ? 'Update address' : 'Save address'); ?></button>
      <a class="ad-btn ad-btn-gray" href="<?php echo e(route('admin.customers.show', $phone)); ?>">Cancel</a>
    </div>
  </form>

  <script>
    (function () {
      var data = <?php echo json_encode($locations, 15, 512) ?>;
      var selDistrict = <?php echo json_encode(old('district', $address->district), 512) ?>;
      var selUpazila  = <?php echo json_encode(old('upazila', $address->upazila), 512) ?>;
      var dEl = document.getElementById('f-district'), uEl = document.getElementById('f-upazila');

      function opt(value, label, selected) {
        var o = document.createElement('option');
        o.value = value; o.textContent = label; if (selected) o.selected = true;
        return o;
      }
      data.forEach(function (d) { dEl.appendChild(opt(d.n, d.n + ' (' + d.b + ')', d.n === selDistrict)); });

      function fillUpazilas(name, keep) {
        uEl.innerHTML = '';
        var d = data.filter(function (x) { return x.n === name; })[0];
        if (!d) { uEl.appendChild(opt('', 'Select district first')); uEl.disabled = true; return; }
        uEl.disabled = false;
        uEl.appendChild(opt('', 'Select upazila'));
        d.u.forEach(function (u) { uEl.appendChild(opt(u[0], u[0] + ' (' + u[1] + ')', keep && u[0] === selUpazila)); });
      }
      dEl.addEventListener('change', function () { fillUpazilas(dEl.value, false); });
      fillUpazilas(selDistrict, true);
    })();
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/customers/addresses/form.blade.php ENDPATH**/ ?>