<?php $__env->startSection('title', 'Record Payment'); ?>

<?php $__env->startSection('content'); ?>
  <p class="ad-crumbs"><a href="<?php echo e(route('admin.payments.index')); ?>">← All payments</a></p>
  <h1 class="ad-title">Record Payment</h1>

  <?php if(!$order): ?>
    <form class="ad-card ad-form" method="GET" action="<?php echo e(route('admin.payments.create')); ?>">
      <label>Order number
        <input type="text" name="order" placeholder="e.g. 125" required autofocus>
      </label>
      <div class="ad-submit"><button type="submit" class="ad-btn">Find order</button></div>
    </form>
  <?php else: ?>
    <?php
      $net    = $order->netPaid();
      $due    = $order->dueAmount();
      $locked = $order->isLocked();
    ?>

    <section class="ad-card">
      <div class="ad-card-head">
        <h2>Order #<?php echo e($order->id); ?> — <?php echo e($order->name); ?></h2>
        <a href="<?php echo e(route('admin.orders.show', $order->id)); ?>">View order →</a>
      </div>
      <dl class="ad-dl">
        <dt>Mobile</dt><dd><?php echo e($order->phone); ?></dd>
        <dt>Order status</dt><dd><span class="ad-st st-<?php echo e($order->status); ?>"><?php echo e($order->statusLabel()); ?></span></dd>
        <dt>Order total</dt><dd>৳ <?php echo e(number_format($order->total)); ?></dd>
        <dt>Received so far</dt><dd>৳ <?php echo e(number_format($net)); ?></dd>
        <dt>Due</dt><dd><strong class="<?php echo e($due > 0 ? 'ad-red' : ''); ?>">৳ <?php echo e(number_format($due)); ?></strong> <span class="ad-st <?php echo e(\App\Models\Order::paymentBadge($order->paymentStatus())); ?>"><?php echo e($order->paymentLabel()); ?></span></dd>
      </dl>
    </section>

    <?php if($locked && $net <= 0): ?>
      <div class="ad-flash ad-warn">This order is <?php echo e(strtolower($order->statusLabel())); ?> and nothing was received, so there is nothing to record.</div>
    <?php elseif($due <= 0 && $net <= 0): ?>
      <div class="ad-flash ad-warn">Nothing to record for this order.</div>
    <?php else: ?>
      <?php echo $__env->make('admin.payments._form', ['order' => $order, 'due' => $due, 'net' => $net, 'locked' => $locked, 'return' => 'payments'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <p><a class="ad-link" href="<?php echo e(route('admin.payments.create')); ?>">Choose another order</a></p>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/payments/create.blade.php ENDPATH**/ ?>