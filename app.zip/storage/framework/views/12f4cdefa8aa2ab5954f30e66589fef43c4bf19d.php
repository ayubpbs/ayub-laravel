<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo $__env->yieldContent('title', config('shop.name') . ' — ' . config('shop.tagline')); ?></title>
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/shop.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/nav.css')); ?>">
  <?php echo $__env->yieldPushContent('head'); ?>
</head>
<body>

<header class="site-header">
  <div class="header-inner">
    <a class="logo" href="<?php echo e(route('home')); ?>">⚡ <?php echo e(config('shop.name')); ?></a>
    <form class="search-form" action="<?php echo e(route('category.index')); ?>" method="GET">
      <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Search products…">
      <button type="submit">Search</button>
    </form>
    <a class="cart-link" href="<?php echo e(route('cart.index')); ?>">🛒 Cart
      <span class="cart-count" id="cart-count" <?php if(\App\Support\Cart::count() < 1): ?> hidden <?php endif; ?>><?php echo e(\App\Support\Cart::count()); ?></span>
    </a>
  </div>
  <?php echo $__env->make('partials.header-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header>

<main class="container">
  <?php if(session('success')): ?>
    <div class="flash flash-ok"><?php echo e(session('success')); ?></div>
  <?php endif; ?>
  <?php if(session('error')): ?>
    <div class="flash flash-err"><?php echo e(session('error')); ?></div>
  <?php endif; ?>

  <?php echo $__env->yieldContent('content'); ?>
</main>

<footer class="site-footer" id="contact">
  <p>© <?php echo e(date('Y')); ?> <?php echo e(config('shop.name')); ?></p>
  <?php if(config('shop.phone')): ?>
    <p>📞 <a href="tel:<?php echo e(config('shop.phone')); ?>"><?php echo e(config('shop.phone')); ?></a></p>
  <?php endif; ?>
</footer>

<div class="toast" id="toast" hidden></div>
<script src="<?php echo e(asset('assets/js/shop.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/nav.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>