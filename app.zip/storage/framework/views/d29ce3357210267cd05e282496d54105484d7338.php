
<nav class="main-nav" id="mainNav" aria-label="Main menu">
  <div class="nav-inner">
    <button class="nav-toggle" type="button" aria-expanded="false" aria-controls="navList">
      <span class="nav-burger" aria-hidden="true"></span>
      <span>Menu</span>
    </button>

    <ul class="nav-list" id="navList">
      <?php $__currentLoopData = \App\Support\NavMenu::items(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(empty($item['children'])): ?>
          <li class="nav-item">
            <a class="nav-link <?php if($item['active']): ?> is-active <?php endif; ?>" href="<?php echo e($item['url']); ?>"
               <?php if($item['active']): ?> aria-current="page" <?php endif; ?>><?php echo e($item['label']); ?></a>
          </li>
        <?php else: ?>
          <li class="nav-item has-sub <?php if($item['active']): ?> is-active <?php endif; ?>">
            <button class="nav-link nav-trigger <?php if($item['active']): ?> is-active <?php endif; ?>" type="button"
                    aria-haspopup="true" aria-expanded="false">
              <?php echo e($item['label']); ?><span class="nav-caret" aria-hidden="true"></span>
            </button>
            <ul class="mega" style="--cols: <?php echo e($item['cols']); ?>">
              <?php $__currentLoopData = $item['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                  <a class="mega-link <?php if($child['active']): ?> is-active <?php endif; ?>" href="<?php echo e($child['url']); ?>"
                     <?php if($child['active']): ?> aria-current="page" <?php endif; ?>><?php echo e($child['label']); ?></a>
                </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </li>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
</nav>
<?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/partials/header-nav.blade.php ENDPATH**/ ?>