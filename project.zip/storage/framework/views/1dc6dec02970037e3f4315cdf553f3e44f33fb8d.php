<?php $__env->startSection('title', 'New Warranty Claim'); ?>

<?php $__env->startSection('content'); ?>
  <?php
    $chip = ['in_warranty' => 'st-delivered', 'expired' => 'st-cancelled', 'not_covered' => 'st-cancelled', 'unknown' => 'st-pending'];
    $chipText = ['in_warranty' => 'In warranty', 'expired' => 'Expired', 'not_covered' => 'No warranty', 'unknown' => 'Date needed'];
    $src = ['product' => 'product policy', 'shop' => 'shop default', 'backfilled' => "today's product settings (old order)", 'continued' => 'continues the original warranty'];
  ?>

  <p class="ad-crumbs"><a href="<?php echo e(route('admin.claims.index', ['kind' => 'warranty'])); ?>">← Warranty claims</a></p>
  <h1 class="ad-title">New warranty claim</h1>

  <?php if(!$order): ?>
    <form class="ad-card ad-form" method="GET" action="<?php echo e(route('admin.claims.warranty.create')); ?>">
      <label>Order number
        <input type="text" name="order" placeholder="e.g. 125" required autofocus>
      </label>
      <div class="ad-submit"><button type="submit" class="ad-btn">Find order</button></div>
      <p class="ad-hint">A warranty claim is made for a <strong>delivered</strong> order. The warranty that applied when the goods were sold is checked for you. The original order and its invoice are never changed.</p>
    </form>
  <?php else: ?>
    <section class="ad-card">
      <div class="ad-card-head">
        <h2>Order #<?php echo e($order->id); ?> — <?php echo e($order->name); ?> <span class="ad-st st-<?php echo e($order->status); ?>"><?php echo e($order->statusLabel()); ?></span></h2>
        <a href="<?php echo e(route('admin.orders.show', $order->id)); ?>">View order →</a>
      </div>
      <dl class="ad-dl">
        <dt>Mobile</dt><dd><?php echo e($order->phone); ?></dd>
        <dt>Delivered</dt><dd><?php echo e($order->delivered_at ? $order->delivered_at->format('d M Y') . ' (' . $order->delivered_at->diffForHumans() . ')' : 'Date not recorded on this order'); ?></dd>
      </dl>
    </section>

    <?php if($order->status !== 'delivered'): ?>
      <div class="ad-flash ad-warn">This order is <?php echo e(strtolower($order->statusLabel())); ?>. A warranty claim can only be opened for a delivered order.</div>
      <p><a class="ad-link" href="<?php echo e(route('admin.claims.warranty.create')); ?>">Choose another order</a></p>
    <?php else: ?>
      <form class="ad-form" method="POST" action="<?php echo e(route('admin.claims.warranty.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">

        <section class="ad-card">
          <h2>1. Which product has the problem?</h2>
          <div class="ad-scroll">
            <table class="ad-table">
              <tr><th></th><th>Product</th><th>Ordered</th><th>Can claim</th><th>Warranty of this purchase</th><th>Check</th></tr>
              <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $a = $r['a']; $p = $a['policy']; ?>
                <tr>
                  <td><input type="radio" name="order_item_id" value="<?php echo e($r['line']->id); ?>" <?php echo e((string) old('order_item_id') === (string) $r['line']->id ? 'checked' : ''); ?> <?php echo e($r['left'] <= 0 ? 'disabled' : ''); ?> required></td>
                  <td><?php echo e($r['line']->title); ?><br><small class="ad-muted">Paid ৳ <?php echo e(number_format($r['line']->price)); ?> each</small></td>
                  <td><?php echo e($r['line']->quantity); ?></td>
                  <td><?php echo e($r['left']); ?></td>
                  <td>
                    <?php if($p['type'] === 'none'): ?>
                      No warranty <small class="ad-muted">(<?php echo e($src[$p['source']] ?? $p['source']); ?>)</small>
                    <?php else: ?>
                      <?php echo e(\App\Support\WarrantyPolicy::typeLabel($p['type'])); ?> · <?php echo e($p['days']); ?> days<br>
                      <small class="ad-muted"><?php echo e($src[$p['source']] ?? $p['source']); ?></small>
                      <?php if($p['terms']): ?><br><small class="ad-muted"><?php echo nl2br(e($p['terms'])); ?></small><?php endif; ?>
                    <?php endif; ?>
                  </td>
                  <td>
                    <span class="ad-st <?php echo e($chip[$a['state']] ?? 'st-pending'); ?>"><?php echo e($chipText[$a['state']] ?? $a['state']); ?></span>
                    <br><small class="ad-muted"><?php echo e($a['message']); ?></small>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
          </div>
        </section>

        <section class="ad-card">
          <h2>2. The problem</h2>
          <div class="ad-row">
            <label>Pieces in this claim *
              <input type="number" name="quantity" min="1" max="999" value="<?php echo e(old('quantity', 1)); ?>" required style="width:110px">
            </label>
            <label>Serial number <small>(optional)</small>
              <input type="text" name="serial_number" maxlength="100" value="<?php echo e(old('serial_number')); ?>">
            </label>
            <?php if (! ($order->delivered_at)): ?>
              <label>Date the customer received it *
                <input type="date" name="start_date" value="<?php echo e(old('start_date')); ?>" max="<?php echo e(now()->toDateString()); ?>" required>
                <small>This order has no recorded delivery date. The warranty counts from this date.</small>
              </label>
            <?php endif; ?>
          </div>
          <label>Why is the customer claiming the warranty? *
            <textarea name="reason" rows="2" maxlength="1000" required placeholder="e.g. Does not switch on"><?php echo e(old('reason')); ?></textarea>
          </label>
          <label>Symptoms <small>(optional: what exactly happens, since when)</small>
            <textarea name="symptoms" rows="3" maxlength="2000"><?php echo e(old('symptoms')); ?></textarea>
          </label>
        </section>

        <section class="ad-card">
          <h2>3. Photos / videos <small>(private, optional)</small></h2>
          <input type="file" name="files[]" multiple accept="image/jpeg,image/png,image/webp,video/mp4,video/quicktime,video/webm">
          <label>Note about the files <small>(optional)</small>
            <input type="text" name="evidence_note" maxlength="250" value="<?php echo e(old('evidence_note')); ?>">
          </label>
          <p class="ad-hint">Up to <?php echo e(\App\Services\ClaimService::MAX_FILES); ?> files. Photos (JPG, PNG, WebP) up to 5 MB, videos (MP4, MOV, WebM) up to 30 MB. Kept in a private folder.</p>
        </section>

        <label class="ad-check">
          <input type="checkbox" name="record_ineligible" value="1" <?php echo e(old('record_ineligible') ? 'checked' : ''); ?>>
          If the warranty has ended (or there is none): save the request anyway, as <strong>rejected</strong>, so there is a record of the call
        </label>

        <div class="ad-submit"><button type="submit" class="ad-btn">Open warranty claim</button></div>
      </form>
    <?php endif; ?>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/claims/warranty_create.blade.php ENDPATH**/ ?>