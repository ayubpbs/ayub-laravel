<?php $__env->startSection('title', 'Payments'); ?>

<?php $__env->startSection('content'); ?>
  <div class="ad-bar">
    <h1 class="ad-title">Payments</h1>
    <a class="ad-btn" href="<?php echo e(route('admin.payments.create')); ?>">＋ Record Payment</a>
  </div>

  <div class="ad-stats">
    <div class="ad-stat"><span class="n">৳ <?php echo e(number_format($summary['today'])); ?></span><span class="l">Received today</span></div>
    <div class="ad-stat"><span class="n">৳ <?php echo e(number_format($summary['month'])); ?></span><span class="l">Received this month</span></div>
    <a class="ad-stat <?php echo e($summary['due'] > 0 ? 'ad-stat-hot' : ''); ?>" href="<?php echo e(route('admin.payments.index', ['tab' => 'due'])); ?>">
      <span class="n">৳ <?php echo e(number_format($summary['due'])); ?></span><span class="l">Still to collect (<?php echo e($summary['due_orders']); ?> orders)</span>
    </a>
    <div class="ad-stat"><span class="n <?php echo e($summary['refund_due'] > 0 ? 'ad-red' : ''); ?>">৳ <?php echo e(number_format($summary['refund_due'])); ?></span><span class="l">To refund (cancelled / returned)</span></div>
  </div>

  <div class="ad-tabs">
    <a href="<?php echo e(route('admin.payments.index')); ?>" class="<?php echo e($tab === 'payments' ? 'on' : ''); ?>">All payments</a>
    <a href="<?php echo e(route('admin.payments.index', ['tab' => 'due'])); ?>" class="<?php echo e($tab === 'due' ? 'on' : ''); ?>">Due orders (<?php echo e($summary['due_orders']); ?>)</a>
  </div>

  <?php if($tab === 'payments'): ?>
    <form class="ad-filter" method="GET" action="<?php echo e(route('admin.payments.index')); ?>">
      <input type="text" name="q" value="<?php echo e($f['q']); ?>" placeholder="Order no., name, mobile or transaction ID…">
      <select name="method">
        <option value="">All methods</option>
        <?php $__currentLoopData = \App\Models\Payment::methods(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($k); ?>" <?php echo e($f['method'] === $k ? 'selected' : ''); ?>><?php echo e($label); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <select name="type">
        <option value="">Payments &amp; refunds</option>
        <option value="payment" <?php echo e($f['type'] === 'payment' ? 'selected' : ''); ?>>Payments only</option>
        <option value="refund"  <?php echo e($f['type'] === 'refund'  ? 'selected' : ''); ?>>Refunds only</option>
      </select>
      <input type="date" name="from" value="<?php echo e($f['from']); ?>" title="From" style="flex:none;min-width:150px;width:160px">
      <input type="date" name="to" value="<?php echo e($f['to']); ?>" title="To" style="flex:none;min-width:150px;width:160px">
      <button type="submit" class="ad-btn ad-btn-gray">Filter</button>
      <?php if(collect($f)->filter()->isNotEmpty()): ?><a class="ad-btn ad-btn-gray" href="<?php echo e(route('admin.payments.index')); ?>">Clear</a><?php endif; ?>
      <a class="ad-btn ad-btn-gray" href="<?php echo e(route('admin.payments.export', array_filter($f))); ?>">⬇ CSV</a>
    </form>

    <section class="ad-card">
      <?php if($payments->isEmpty()): ?>
        <p class="ad-muted">No payments found.</p>
      <?php else: ?>
        <div class="ad-scroll">
          <table class="ad-table">
            <tr><th>Date</th><th>Order</th><th>Customer</th><th>Method</th><th>Transaction</th><th class="r">Amount</th><th></th></tr>
            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($p->paid_at->format('d M Y, h:i A')); ?></td>
                <td><a href="<?php echo e(route('admin.orders.show', $p->order_id)); ?>"><strong>#<?php echo e($p->order_id); ?></strong></a></td>
                <td><?php echo e(optional($p->order)->name); ?><br><small class="ad-muted"><?php echo e(optional($p->order)->phone); ?></small></td>
                <td><?php echo e($p->methodLabel()); ?> <?php if($p->isRefund()): ?><span class="ad-st st-returned">Refund</span><?php endif; ?></td>
                <td><?php echo e($p->trx_id ?: '—'); ?><?php if($p->sender_number): ?><br><small class="ad-muted">from <?php echo e($p->sender_number); ?></small><?php endif; ?> <?php if($p->note): ?><br><small class="ad-muted"><?php echo e($p->note); ?></small><?php endif; ?></td>
                <td class="r <?php echo e($p->isRefund() ? 'ad-red' : ''); ?>"><strong><?php echo e($p->isRefund() ? '−' : ''); ?>৳ <?php echo e(number_format($p->amount)); ?></strong></td>
                <td>
                  <form action="<?php echo e(route('admin.payments.destroy', $p->id)); ?>" method="POST" onsubmit="return confirm('Delete this payment record? The order\'s due amount will change.');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="ad-link ad-del">Delete</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
        </div>
        <div class="ad-pager"><?php echo e($payments->links('pagination::simple-default')); ?></div>
      <?php endif; ?>
    </section>
  <?php else: ?>
    <form class="ad-filter" method="GET" action="<?php echo e(route('admin.payments.index')); ?>">
      <input type="hidden" name="tab" value="due">
      <input type="text" name="q" value="<?php echo e($q); ?>" placeholder="Order no., name or mobile…">
      <select name="status">
        <option value="">All order statuses</option>
        <?php $__currentLoopData = \App\Models\Order::statuses(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if (! (in_array($k, \App\Models\Order::lockedStatuses()))): ?>
            <option value="<?php echo e($k); ?>" <?php echo e($status === $k ? 'selected' : ''); ?>><?php echo e($label); ?></option>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <button type="submit" class="ad-btn ad-btn-gray">Filter</button>
      <?php if($q !== '' || $status !== ''): ?><a class="ad-btn ad-btn-gray" href="<?php echo e(route('admin.payments.index', ['tab' => 'due'])); ?>">Clear</a><?php endif; ?>
    </form>

    <section class="ad-card">
      <?php if($orders->isEmpty()): ?>
        <p class="ad-muted">Nothing is due. Every live order is fully paid.</p>
      <?php else: ?>
        <form method="POST" action="<?php echo e(route('admin.payments.collect.bulk')); ?>"
              onsubmit="return confirm(event.submitter && event.submitter.dataset.one ? 'Record the full due amount of this order as cash on delivery collected?' : 'Record the full due amount of the ticked orders as cash on delivery collected?');">
          <?php echo csrf_field(); ?>
          <div class="ad-scroll">
            <table class="ad-table">
              <tr><th><input type="checkbox" id="checkAll" aria-label="Select all"></th><th>Order</th><th>Customer</th><th>Status</th><th class="r">Total</th><th class="r">Paid</th><th class="r">Due</th><th></th></tr>
              <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><input type="checkbox" name="ids[]" value="<?php echo e($o->id); ?>" class="rowCheck"></td>
                  <td><a href="<?php echo e(route('admin.orders.show', $o->id)); ?>"><strong>#<?php echo e($o->id); ?></strong></a><br><small class="ad-muted"><?php echo e($o->created_at->format('d M')); ?></small></td>
                  <td><?php echo e($o->name); ?><br><small class="ad-muted"><?php echo e($o->phone); ?></small></td>
                  <td><span class="ad-st st-<?php echo e($o->status); ?>"><?php echo e($o->statusLabel()); ?></span></td>
                  <td class="r">৳ <?php echo e(number_format($o->total)); ?></td>
                  <td class="r">৳ <?php echo e(number_format($o->netPaid())); ?></td>
                  <td class="r ad-red"><strong>৳ <?php echo e(number_format($o->dueAmount())); ?></strong></td>
                  <td class="ad-actions">
                    <button type="submit" class="ad-link" data-one="1" formaction="<?php echo e(route('admin.payments.collect', $o->id)); ?>">Mark paid</button>
                    <a class="ad-link" href="<?php echo e(route('admin.payments.create', ['order' => $o->id])); ?>">Part payment</a>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
          </div>
          <div class="ad-submit" style="margin-top:12px">
            <button type="submit" class="ad-btn ad-btn-gray">Mark ticked orders as paid (cash on delivery)</button>
          </div>
        </form>
        <div class="ad-pager"><?php echo e($orders->links('pagination::simple-default')); ?></div>
        <script>
          document.getElementById('checkAll').addEventListener('change', function () {
            document.querySelectorAll('.rowCheck').forEach(function (c) { c.checked = this.checked; }, this);
          });
        </script>
        <p class="ad-hint">"Mark paid" records the full remaining amount as cash on delivery. Use it once the money has reached you (or after Steadfast has paid you out).</p>
      <?php endif; ?>
    </section>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/payments/index.blade.php ENDPATH**/ ?>