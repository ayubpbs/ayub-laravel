<?php $__env->startSection('title', 'New Claim'); ?>

<?php $__env->startSection('content'); ?>
  <p class="ad-crumbs"><a href="<?php echo e(route('admin.claims.index')); ?>">← All claims</a></p>
  <h1 class="ad-title">New claim</h1>

  <?php if(!$order): ?>
    <form class="ad-card ad-form" method="GET" action="<?php echo e(route('admin.claims.create')); ?>">
      <label>Order number
        <input type="text" name="order" placeholder="e.g. 125" required autofocus>
      </label>
      <div class="ad-submit"><button type="submit" class="ad-btn">Find order</button></div>
      <p class="ad-hint">A claim can only be opened for a <strong>delivered</strong> order. The original order and its invoice are never changed.</p>
    </form>
  <?php else: ?>
    <section class="ad-card">
      <div class="ad-card-head">
        <h2>Order #<?php echo e($order->id); ?> — <?php echo e($order->name); ?> <span class="ad-st st-<?php echo e($order->status); ?>"><?php echo e($order->statusLabel()); ?></span></h2>
        <a href="<?php echo e(route('admin.orders.show', $order->id)); ?>">View order →</a>
      </div>
      <dl class="ad-dl">
        <dt>Mobile</dt><dd><?php echo e($order->phone); ?></dd>
        <dt>Delivered</dt><dd><?php echo e($order->delivered_at ? $order->delivered_at->format('d M Y') . ' (' . $order->delivered_at->diffForHumans() . ')' : 'Date not recorded'); ?></dd>
        <dt>Order total</dt><dd>৳ <?php echo e(number_format($order->total)); ?></dd>
      </dl>
    </section>

    <?php if($order->status !== 'delivered'): ?>
      <div class="ad-flash ad-warn">This order is <?php echo e(strtolower($order->statusLabel())); ?>. A claim can only be opened for a delivered order.</div>
      <p><a class="ad-link" href="<?php echo e(route('admin.claims.create')); ?>">Choose another order</a></p>
    <?php elseif(array_sum($left) <= 0): ?>
      <div class="ad-flash ad-warn">Every piece of this order is already in another claim.</div>
      <p><a class="ad-link" href="<?php echo e(route('admin.claims.create')); ?>">Choose another order</a></p>
    <?php else: ?>
      <form class="ad-form" method="POST" action="<?php echo e(route('admin.claims.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">

        <section class="ad-card">
          <h2>1. What is wrong?</h2>
          <div class="ad-row">
            <label>Type of claim *
              <select name="type" id="c-type" required>
                <option value="">Choose…</option>
                <?php $__currentLoopData = \App\Models\ServiceRequest::types(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($k); ?>" <?php echo e(old('type') === $k ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </label>
          </div>
          <label>What the customer says
            <textarea name="reason" rows="3" maxlength="2000" placeholder="Describe the problem in the customer's words"><?php echo e(old('reason')); ?></textarea>
          </label>
          <label class="ad-check">
            <input type="checkbox" name="return_required" value="1" <?php echo e(old('return_required', '1') ? 'checked' : ''); ?>>
            The goods must come back to us (we inspect them before anything goes on the shelf)
          </label>
        </section>

        <section class="ad-card">
          <h2>2. Which products?</h2>
          <p class="ad-hint">Enter how many pieces are part of the claim. Leave 0 for products that are fine.</p>
          <div class="ad-scroll">
            <table class="ad-table">
              <tr><th>Product</th><th>Price paid</th><th>Ordered</th><th>Can claim</th><th>Claim qty</th><th class="c-recv" hidden>Product received (ID)</th></tr>
              <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($it->title); ?></td>
                  <td>৳ <?php echo e(number_format($it->price)); ?></td>
                  <td><?php echo e($it->quantity); ?></td>
                  <td><?php echo e($left[$it->id] ?? 0); ?></td>
                  <td><input type="number" name="qty[<?php echo e($it->id); ?>]" min="0" max="<?php echo e($left[$it->id] ?? 0); ?>" value="<?php echo e(old('qty.' . $it->id, 0)); ?>" style="width:90px" <?php echo e(($left[$it->id] ?? 0) <= 0 ? 'disabled' : ''); ?>></td>
                  <td class="c-recv" hidden><input type="number" name="received[<?php echo e($it->id); ?>]" min="1" value="<?php echo e(old('received.' . $it->id)); ?>" placeholder="same product" style="width:130px"></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
          </div>
          <p class="ad-hint c-recv" hidden>Wrong product only: if the customer received a different product that is in your shop, enter its product ID so it is counted correctly if it goes back to stock. Leave empty if it is the same product.</p>
        </section>

        <section class="ad-card">
          <h2>3. Photos / videos <small>(private, optional)</small></h2>
          <input type="file" name="files[]" multiple accept="image/jpeg,image/png,image/webp,video/mp4,video/quicktime,video/webm">
          <label>Note about the files <small>(optional)</small>
            <input type="text" name="evidence_note" maxlength="250" value="<?php echo e(old('evidence_note')); ?>">
          </label>
          <p class="ad-hint">Up to <?php echo e(\App\Services\ClaimService::MAX_FILES); ?> files. Photos (JPG, PNG, WebP) up to 5 MB, videos (MP4, MOV, WebM) up to 30 MB. They are kept in a private folder and only people with the claims permission can open them.</p>
        </section>

        <div class="ad-submit"><button type="submit" class="ad-btn">Open claim</button></div>
      </form>

      <script>
        (function () {
          var t = document.getElementById('c-type');
          function sync() { document.querySelectorAll('.c-recv').forEach(function (e) { e.hidden = t.value !== 'wrong_product'; }); }
          t.addEventListener('change', sync); sync();
        })();
      </script>
    <?php endif; ?>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/claims/create.blade.php ENDPATH**/ ?>