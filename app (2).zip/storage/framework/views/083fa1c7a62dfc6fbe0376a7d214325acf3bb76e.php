<?php $__env->startSection('title', 'Claims'); ?>

<?php $__env->startSection('content'); ?>
  <?php $ax = \App\Support\AdminAccess::class; ?>

  <?php if(!$ready): ?>
    <h1 class="ad-title">Claims</h1>
    <div class="ad-flash ad-err">The claim tables are missing. Run <code>php artisan migrate</code>, then reload this page.</div>
  <?php else: ?>
    <div class="ad-bar">
      <h1 class="ad-title"><?php echo e($status === '' ? 'All Claims' : \App\Models\ServiceRequest::statuses()[$status] . ' Claims'); ?></h1>
      <form method="GET" action="<?php echo e(route('admin.claims.index')); ?>" class="ad-filter" style="margin:0">
        <?php if($status !== ''): ?><input type="hidden" name="status" value="<?php echo e($status); ?>"><?php endif; ?>
        <input type="text" name="q" value="<?php echo e($q); ?>" placeholder="Search name, mobile, claim or order no.">
        <button type="submit" class="ad-btn">Search</button>
        <?php if($q !== ''): ?><a class="ad-btn ad-btn-gray" href="<?php echo e(route('admin.claims.index', $status !== '' ? ['status' => $status] : [])); ?>">Clear</a><?php endif; ?>
      </form>
      <?php if($ax::can('claims_manage')): ?>
        <a class="ad-btn" href="<?php echo e(route('admin.claims.create')); ?>">+ New claim</a>
      <?php endif; ?>
    </div>

    <div class="ad-tabs">
      <a href="<?php echo e(route('admin.claims.index')); ?>" class="<?php echo e($status === '' ? 'on' : ''); ?>">All (<?php echo e($counts->sum()); ?>)</a>
      <?php $__currentLoopData = \App\Models\ServiceRequest::statuses(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('admin.claims.index', ['status' => $key])); ?>" class="<?php echo e($status === $key ? 'on' : ''); ?>"><?php echo e($label); ?> (<?php echo e($counts[$key] ?? 0); ?>)</a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <section class="ad-card">
      <?php if($claims->isEmpty()): ?>
        <p class="ad-muted"><?php echo e($q !== '' ? 'No claims match your search.' : 'No claims yet.'); ?></p>
      <?php else: ?>
        <div class="ad-scroll">
          <table class="ad-table">
            <tr><th>Claim</th><th>Opened</th><th>Customer</th><th>Order</th><th>Type</th><th>Solution</th><th>Status</th></tr>
            <?php $__currentLoopData = $claims; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><a href="<?php echo e(route('admin.claims.show', $c->id)); ?>"><strong>#<?php echo e($c->id); ?></strong></a></td>
                <td><?php echo e($c->created_at->format('d M Y, h:i A')); ?></td>
                <td><?php echo e($c->customer_name); ?><br><small class="ad-muted"><?php echo e($c->customer_phone); ?></small></td>
                <td><a class="ad-link" href="<?php echo e(route('admin.orders.show', $c->order_id)); ?>">#<?php echo e($c->order_id); ?></a></td>
                <td><?php echo e($c->typeLabel()); ?></td>
                <td><?php echo e($c->resolution ? ucfirst($c->resolution) : '—'); ?></td>
                <td><span class="ad-st <?php echo e(\App\Models\ServiceRequest::badge($c->status)); ?>"><?php echo e($c->statusLabel()); ?></span></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
        </div>
        <div class="ad-pager"><?php echo e($claims->links('pagination::simple-default')); ?></div>
      <?php endif; ?>
    </section>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayub-laravel\resources\views/admin/claims/index.blade.php ENDPATH**/ ?>