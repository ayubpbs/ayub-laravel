@extends('admin.layout')

@section('title', 'Order #' . $order->id)

@section('content')
  <p class="ad-crumbs"><a href="{{ route('admin.orders.index') }}">← All orders</a></p>
  <h1 class="ad-title">Order #{{ $order->id }} <span class="ad-st st-{{ $order->status }}">{{ $order->statusLabel() }}</span></h1>

  <div class="ad-two">
    <section class="ad-card">
      <h2>Customer details</h2>
      <dl class="ad-dl">
        <dt>Name</dt><dd>{{ $order->name }}</dd>
        <dt>Mobile</dt><dd><a href="tel:{{ $order->phone }}">{{ $order->phone }}</a> · <a class="ad-link" href="{{ route('admin.customers.show', $order->phone) }}">Customer history</a></dd>
        <dt>Address</dt><dd>{{ $order->address }}</dd>
        @if ($order->district)
          <dt>District</dt><dd>{{ $order->district }}@if ($order->upazila) · {{ $order->upazila }}@endif @if ($order->city) · {{ $order->city }}@endif</dd>
        @endif
        @if ($order->note)
          <dt>Note</dt><dd>{{ $order->note }}</dd>
        @endif
        <dt>Order time</dt><dd>{{ $order->created_at->format('d M Y, h:i A') }}</dd>
        <dt>Payment</dt><dd>Cash on delivery</dd>
      </dl>
    </section>

    <section class="ad-card">
      <h2>Change status</h2>
      @if ($order->isLocked())
        <p class="ad-muted">This order is {{ strtolower($order->statusLabel()) }}, so its status can no longer be changed.</p>
      @else
        <form action="{{ route('admin.orders.status', $order->id) }}" method="POST" class="ad-form">
          @csrf
          <select name="status">
            @foreach (\App\Models\Order::statuses() as $key => $label)
              <option value="{{ $key }}" {{ $order->status === $key ? 'selected' : '' }}>{{ $label }}</option>
            @endforeach
          </select>
          <button type="submit" class="ad-btn">Save</button>
        </form>
        <p class="ad-hint">Choosing "Cancelled" or "Returned" puts the products back in stock, and the status cannot be changed afterwards.</p>
      @endif
    </section>
  </div>

  @php
    $net  = $order->netPaid();
    $due  = $order->dueAmount();
    $inv  = $order->invoice;
  @endphp
  <section class="ad-card">
    <div class="ad-card-head">
      <h2>Payment <span class="ad-st {{ \App\Models\Order::paymentBadge($order->paymentStatus()) }}">{{ $order->paymentLabel() }}</span></h2>
      @if ($inv)
        <a href="{{ route('admin.invoices.show', $inv->id) }}" target="_blank">🖨 Invoice {{ $inv->number() }}</a>
      @endif
    </div>

    <dl class="ad-dl">
      <dt>Order total</dt><dd>৳ {{ number_format($order->total) }}</dd>
      <dt>Received</dt><dd>৳ {{ number_format($net) }}</dd>
      <dt>{{ $order->isLocked() ? 'To refund' : 'Due' }}</dt>
      <dd><strong class="{{ ($order->isLocked() ? $net : $due) > 0 ? 'ad-red' : '' }}">৳ {{ number_format($order->isLocked() ? max(0, $net) : $due) }}</strong></dd>
    </dl>

    @if ($order->payments->isNotEmpty())
      <div class="ad-scroll" style="margin-top:12px">
        <table class="ad-table">
          <tr><th>Date</th><th>Method</th><th>Transaction</th><th class="r">Amount</th><th></th></tr>
          @foreach ($order->payments->sortBy('paid_at') as $p)
            <tr>
              <td>{{ $p->paid_at->format('d M Y, h:i A') }}</td>
              <td>{{ $p->methodLabel() }} @if ($p->isRefund())<span class="ad-st st-returned">Refund</span>@endif</td>
              <td>{{ $p->trx_id ?: '—' }}@if ($p->note)<br><small class="ad-muted">{{ $p->note }}</small>@endif</td>
              <td class="r {{ $p->isRefund() ? 'ad-red' : '' }}">{{ $p->isRefund() ? '−' : '' }}৳ {{ number_format($p->amount) }}</td>
              <td>
                <form action="{{ route('admin.payments.destroy', $p->id) }}" method="POST" onsubmit="return confirm('Delete this payment record?');">
                  @csrf
                  @method('DELETE')
                  <button type="submit" class="ad-link ad-del">Delete</button>
                </form>
              </td>
            </tr>
          @endforeach
        </table>
      </div>
    @endif

    <div class="ad-submit" style="margin-top:12px">
      @if (!$order->isLocked() && $due > 0)
        <form action="{{ route('admin.payments.collect', $order->id) }}" method="POST" onsubmit="return confirm('Record ৳ {{ number_format($due) }} as cash on delivery collected?');">
          @csrf
          <button type="submit" class="ad-btn">✔ Mark fully paid (cash on delivery)</button>
        </form>
      @endif
      @if (!$order->isLocked() || $net > 0)
        <a class="ad-btn ad-btn-gray" href="{{ route('admin.payments.create', ['order' => $order->id]) }}">Record payment / refund</a>
      @endif
      @if (!$inv && !$order->isLocked())
        <form action="{{ route('admin.invoices.generate', $order->id) }}" method="POST">
          @csrf
          <button type="submit" class="ad-btn ad-btn-gray">Create invoice</button>
        </form>
      @endif
    </div>
  </section>

  <section class="ad-card">
    <h2>Courier</h2>
    @if ($order->consignment_id)
      <dl class="ad-dl">
        <dt>Courier</dt><dd>Steadfast</dd>
        <dt>Consignment</dt><dd>{{ $order->consignment_id }}</dd>
        <dt>Tracking code</dt><dd>{{ $order->tracking_code ?: '—' }}</dd>
        <dt>Courier status</dt><dd><span class="ad-st {{ \App\Support\Steadfast::badge($order->courier_status) }}">{{ \App\Support\Steadfast::label($order->courier_status) }}</span></dd>
        <dt>Sent</dt><dd>{{ optional($order->courier_sent_at)->format('d M Y, h:i A') }}</dd>
      </dl>
      <form action="{{ route('admin.courier.refresh', $order->id) }}" method="POST" style="margin-top:12px">
        @csrf
        <button type="submit" class="ad-btn ad-btn-gray">⟳ Refresh courier status</button>
      </form>
    @elseif ($order->status === 'confirmed')
      <p class="ad-muted">Not sent to a courier yet.</p>
      <form action="{{ route('admin.courier.send', $order->id) }}" method="POST" onsubmit="return confirm('Send order #{{ $order->id }} to Steadfast now?');">
        @csrf
        <button type="submit" class="ad-btn">🚚 Send to Steadfast</button>
      </form>
    @else
      <p class="ad-muted">An order can be sent to Steadfast once it is "Confirmed".</p>
    @endif
  </section>

  <section class="ad-card">
    <h2>Items</h2>
    <div class="ad-scroll">
      <table class="ad-table">
        <tr><th>Product</th><th>Price</th><th>Quantity</th><th class="r">Total</th></tr>
        @foreach ($order->items as $item)
          <tr>
            <td>{{ $item->title }}</td>
            <td>৳ {{ number_format($item->price) }}</td>
            <td>{{ $item->quantity }}</td>
            <td class="r">৳ {{ number_format($item->line_total) }}</td>
          </tr>
        @endforeach
        <tr><td colspan="3" class="r">Subtotal</td><td class="r">৳ {{ number_format($order->subtotal) }}</td></tr>
        @if ($order->discount > 0)
          <tr><td colspan="3" class="r">Discount @if ($order->coupon_code)<span class="ad-st st-confirmed">{{ $order->coupon_code }}</span>@endif</td><td class="r ad-green">− ৳ {{ number_format($order->discount) }}</td></tr>
        @endif
        <tr><td colspan="3" class="r">Delivery charge</td><td class="r">৳ {{ number_format($order->delivery_charge) }}</td></tr>
        <tr class="ad-total"><td colspan="3" class="r">Total</td><td class="r">৳ {{ number_format($order->total) }}</td></tr>
      </table>
    </div>
  </section>
@endsection
