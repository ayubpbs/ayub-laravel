<?php

namespace App\Http\Controllers\Admin\Accounting;

use App\Http\Controllers\Controller;
use App\Models\Account;
use Illuminate\Http\Request;

class AccountController extends Controller
{
    public function show(Request $request, $type)
    {
        $account = $this->account($type);

        $date = fn ($v) => preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) $v) ? (string) $v : '';
        $f = [
            'from' => $date($request->query('from')),
            'to'   => $date($request->query('to')),
            'dir'  => in_array($request->query('dir'), ['in', 'out'], true) ? $request->query('dir') : '',
        ];
        $filtered = $f['from'] !== '' || $f['to'] !== '' || $f['dir'] !== '';

        $apply = function ($q) use ($f) {
            if ($f['from'] !== '') $q->whereDate('txn_date', '>=', $f['from']);
            if ($f['to'] !== '')   $q->whereDate('txn_date', '<=', $f['to']);
            if ($f['dir'] !== '')  $q->where('direction', $f['dir']);

            return $q;
        };

        $transactions = $apply($account->transactions())
            ->orderByDesc('txn_date')->orderByDesc('id')
            ->paginate(20)->withQueryString();

        $period = [
            'in'  => (float) $apply($account->transactions())->where('direction', 'in')->sum('amount'),
            'out' => (float) $apply($account->transactions())->where('direction', 'out')->sum('amount'),
        ];

        return view('admin.accounting.accounts.show', [
            'type'         => $type,
            'info'         => Account::types()[$type],
            'account'      => $account,
            'totals'       => $account->totals(),
            'transactions' => $transactions,
            'f'            => $f,
            'filtered'     => $filtered,
            'period'       => $period,
        ]);
    }

    public function store(Request $request, $type)
    {
        $account = $this->account($type);

        $data = $request->validate([
            'direction' => 'required|in:in,out',
            'amount'    => 'required|numeric|min:0.01|max:99999999',
            'txn_date'  => 'required|date',
            'note'      => 'nullable|string|max:255',
        ], [
            'direction.required' => 'Please choose Money In or Money Out.',
            'amount.required'    => 'Please enter the amount.',
            'amount.min'         => 'The amount must be greater than zero.',
            'txn_date.required'  => 'Please choose the date.',
        ]);

        $account->transactions()->create([
            'direction' => $data['direction'],
            'amount'    => $data['amount'],
            'txn_date'  => $data['txn_date'],
            'note'      => isset($data['note']) ? trim($data['note']) : null,
            'source'    => 'manual',
        ]);

        return redirect()->route('admin.accounting.accounts.show', $type)->with('success', 'Entry added.');
    }

    public function destroy($type, $id)
    {
        $tx = $this->account($type)->transactions()->findOrFail($id);

        // Entries created by other modules later (income, expense, transfer) must be changed from there
        if ($tx->source !== 'manual') {
            return back()->with('error', 'This entry was created by another module. Change it from there.');
        }

        $tx->delete();

        return redirect()->route('admin.accounting.accounts.show', $type)->with('success', 'Entry deleted.');
    }

    public function updateOpening(Request $request, $type)
    {
        $account = $this->account($type);

        $data = $request->validate([
            'opening_balance' => 'required|numeric|min:0|max:99999999',
        ], [
            'opening_balance.required' => 'Please enter the opening balance.',
        ]);

        $account->update(['opening_balance' => $data['opening_balance']]);

        return redirect()->route('admin.accounting.accounts.show', $type)->with('success', 'Opening balance saved.');
    }

    private function account(string $type): Account
    {
        abort_unless(isset(Account::types()[$type]), 404);

        return Account::forType($type);
    }
}
